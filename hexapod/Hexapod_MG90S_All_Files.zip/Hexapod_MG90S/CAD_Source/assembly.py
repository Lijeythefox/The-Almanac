import sys, itertools
sys.path.insert(0, '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work')
from parts import *

def T(t):
    return M(np.eye(3), t)

def R4(R):
    return M(R, [0, 0, 0])

def leg_mats(i, a=0.0, b=20.0, c=20.0):
    """a: coxa (deg, ccw), b: femur up (deg), c: knee (deg, +ve = tibia tip swings outward)"""
    LA = leg_frame(i) @ R4(rotz(a))
    LB = LA @ T([X_FEMUR, 0, Z_FEMUR]) @ R4(roty(-b))
    LC = LB @ T([L_FEMUR, 0, 0]) @ R4(roty(-c))
    return LA, LB, LC

_cache = {}
def P(name):
    if name not in _cache:
        _cache[name] = dict(Leg_A=leg_a, Leg_B=leg_b, Leg_C_1=leg_c1, Leg_C_2=leg_c2, Body=body,
                            Upper_Body=lid, servo=servo_body_only)[name]()
    return _cache[name]

def servo_body_only():
    parts = [box(X_IN, X_OUT, -SW / 2, SW / 2, -19.0, 4.5),
             box(X_C - TAB_SPAN / 2, X_C + TAB_SPAN / 2, -SW / 2, SW / 2, -TAB_T, 0),
             cyl(SW / 2 - 0.3, 4.5, 8.2, 0, 0),
             cyl(3.5, 8.2, 11.4, 0, 0)]
    return union(parts)

def ov(a, ma, b, mb):
    return (apply(a, ma) ^ apply(b, mb)).volume()

def check_leg(i, a, b, c, verbose=False):
    LA, LB, LC = leg_mats(i, a, b, c)
    I = np.eye(4)
    res = {}
    res['body-legA'] = ov(P('Body'), I, P('Leg_A'), LA)
    res['lid-legA'] = ov(P('Upper_Body'), I, P('Leg_A'), LA)
    res['body-legB'] = ov(P('Body'), I, P('Leg_B'), LB)
    res['legA-legB'] = ov(P('Leg_A'), LA, P('Leg_B'), LB)
    res['legB-legC1'] = ov(P('Leg_B'), LB, P('Leg_C_1'), LC)
    res['legA-legC1'] = ov(P('Leg_A'), LA, P('Leg_C_1'), LC)
    res['legA-foot'] = ov(P('Leg_A'), LA, P('Leg_C_2'), LC)
    res['legB-foot'] = ov(P('Leg_B'), LB, P('Leg_C_2'), LC)
    res['c1-foot'] = ov(P('Leg_C_1'), LC, P('Leg_C_2'), LC)
    sv = P('servo')
    res['s1-body'] = ov(sv, leg_frame(i), P('Body'), I)
    res['s1-legA'] = ov(sv, leg_frame(i), P('Leg_A'), LA)
    res['s2-legA'] = ov(sv, LA @ S2, P('Leg_A'), LA)
    res['s2-legB'] = ov(sv, LA @ S2, P('Leg_B'), LB)
    res['s3-legB'] = ov(sv, LB @ S3, P('Leg_B'), LB)
    res['s3-legC1'] = ov(sv, LB @ S3, P('Leg_C_1'), LC)
    res['s3-legA'] = ov(sv, LB @ S3, P('Leg_A'), LA)
    bad = {k: round(v, 1) for k, v in res.items() if v > 0.5}
    return bad

def foot_tip(i, a, b, c):
    LA, LB, LC = leg_mats(i, a, b, c)
    return (LC @ np.array([-6.0, 0, -TIBIA_TIP - 3.0, 1]))[:3]

if __name__ == '__main__':
    print('neutral', check_leg(0, 0, 20, -20))
    for a in (-40, 0, 40):
        for b in (-50, 0, 60):
            for c in (-90, -60, -30, 0, 40):
                bad = check_leg(0, a, b, c)
                if bad:
                    print(a, b, c, bad)
    print('foot tip at neutral', foot_tip(0, 0, 20, -20))
