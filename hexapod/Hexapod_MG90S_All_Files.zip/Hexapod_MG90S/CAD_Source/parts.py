import sys
sys.path.insert(0, '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work')
from cad import *

# ------------------------------------------------------------ geometry
R_COXA = 70.0          # body centre -> coxa axis
TAB_Y = 6.5            # tab plane offset along joint axis (fork centred on 0)
X_FEMUR = 24.85        # coxa axis -> femur axis (radial)
Z_FEMUR = -1.0
L_FEMUR = 52.0         # femur axis -> knee axis
TIBIA_TIP = 90.0       # knee axis -> foot tip
BASE_Z0, BASE_Z1 = -33.5, -30.0   # tibia bracket base (knee frame)

# S-frame placements -------------------------------------------------
# coxa servo in body leg frame L: S == L
S1 = np.eye(4)
# femur servo in Leg_A coords (= L): x_S->+Z, y_S->+X, z_S->+Y
S2 = M([[0, 1, 0], [0, 0, 1], [1, 0, 0]], [X_FEMUR, TAB_Y, Z_FEMUR])
# knee servo in Leg_B coords (x=along femur, y=joint axis, z=up): x_S->+x, y_S->-z, z_S->+y
S3 = M([[1, 0, 0], [0, 0, 1], [0, -1, 0]], [L_FEMUR, TAB_Y, 0])
# the child link sees the joint with its own axis at the origin; the horn arm is at +y
def joint_frame_child():
    # x_S->+x, y_S->-z, z_S->+y, origin at (0, TAB_Y, 0)
    return M([[1, 0, 0], [0, 0, 1], [0, -1, 0]], [0, TAB_Y, 0])

def y_arm(z0, z1):
    """y range of arms in child coords (horn arm +y, pivot arm -y)."""
    return z0 + TAB_Y, z1 + TAB_Y

HORN_Y = (HORN_FACE + TAB_Y, HORN_FACE + ARM_T + TAB_Y)      # 19.5 .. 23
PIV_Y = (PIVOT_FACE - ARM_T + TAB_Y, PIVOT_FACE + TAB_Y)     # -23 .. -19.5
CAR_YLO = CAR_Z0 + TAB_Y                                     # -18.5

def xz_extrude(cs, y0, y1):
    """CrossSection in (x, z) plane -> solid spanning y0..y1."""
    m = cs.extrude(y1 - y0)            # along +z
    # map (x, y, z) -> (x, z_world=y, y_world=z)
    m = m.transform(np.array([[1, 0, 0, 0], [0, 0, 1, y0], [0, 1, 0, 0]], float))
    return m

# ================================================================ Leg_A (coxa)
def leg_a():
    zt0, zt1 = HORN_FACE, HORN_FACE + ARM_T                   # top plate 13..16.5
    zb0, zb1 = PIVOT_FACE - ARM_T, PIVOT_FACE                 # bottom plate -29.5..-26
    web_x0, web_x1 = X_FEMUR - CAR_Y, X_FEMUR - CAR_Y + 3.0   # 16.5..19.5
    plate_cs = CrossSection.batch_hull([circ(9.5), rect(5, web_x1, CAR_YLO, 9.5)])
    top = plate_cs.extrude(zt1 - zt0).translate([0, 0, zt0])
    bot = plate_cs.extrude(zb1 - zb0).translate([0, 0, zb0])
    web = rbox(web_x0, web_x1, CAR_YLO, TAB_Y, zb0, zt1, 1.0)
    car = apply(carrier_solid(), S2)
    body = union([top, bot, web, car])
    cuts = placed(carrier_cuts(), S2)
    cuts += [m.rotate([0, 0, 0]) for m in placed(horn_arm_cuts(0), S1)]
    cuts += placed(pivot_arm_cuts(), S1)
    # trim plates so the femur horn sweep stays clear
    return diff(body, cuts)

# ================================================================ Leg_B (femur)
def leg_b():
    lobe = CrossSection.batch_hull([circ(13.0), rect(0, 19.5, -9.0, 9.0)]) ^ rect(-20, 30, -8.35, 8.35)
    arm_h = xz_extrude(lobe, *HORN_Y)
    arm_p = xz_extrude(lobe, *PIV_Y)
    bridge = rbox(16.0, 19.5, PIV_Y[0], HORN_Y[1], -8.35, 8.35, 1.0)
    # taper from full fork width to the knee carrier width
    t0 = xz_extrude(rect(16.0, 19.5, -8.35, 8.35), PIV_Y[0], HORN_Y[1])
    t1 = xz_extrude(rect(21.5, 29.0, -8.35, 8.35), CAR_YLO, TAB_Y)
    taper = Manifold.batch_hull([t0, t1])
    car = apply(carrier_solid(), S3)
    body = union([arm_h, arm_p, bridge, taper, car])
    jf = joint_frame_child()
    cuts = placed(horn_arm_cuts(0), jf) + placed(pivot_arm_cuts(), jf)
    cuts += placed(carrier_cuts(), S3)
    return diff(body, cuts)

# ================================================================ Leg_C_1 (tibia bracket)
FOOT_SCREWS = ((-3.6, 0.0), (3.6, 0.0))
INS_R, INS_DEPTH = 1.55, 5.0   # M2 heat-set insert hole (3.1 mm dia)

def leg_c1():
    prof = CrossSection.batch_hull([circ(13.0), rect(-7, 7, BASE_Z0, -20)])
    arm_h = xz_extrude(prof, *HORN_Y)
    arm_p = xz_extrude(prof, *PIV_Y)
    base = rbox(-7, 7, PIV_Y[0], HORN_Y[1], BASE_Z0, BASE_Z1, 1.5)
    # gussets
    g = []
    for y0, y1 in ((HORN_Y[0] - 3, HORN_Y[0]), (PIV_Y[1], PIV_Y[1] + 3)):
        tri = CrossSection([np.array([[-11, BASE_Z1], [11, BASE_Z1], [11, BASE_Z1 + 0.01], [-11, BASE_Z1 + 0.01]])])
        w = box(-7, 7, y0, y1, BASE_Z1 - 0.01, BASE_Z1 + 3)
        g.append(w)
    body = union([arm_h, arm_p, base] + g)
    jf = joint_frame_child()
    cuts = placed(horn_arm_cuts(90), jf) + placed(pivot_arm_cuts(), jf)
    # foot screws: M2 clearance + head counterbore from inside
    for (fx, fy) in FOOT_SCREWS:
        cuts.append(cyl(1.15, BASE_Z0 - 1, BASE_Z1 + 5, fx, fy, 24))
        cuts.append(cyl(2.1, BASE_Z1 - 1.2, BASE_Z1 + 6, fx, fy, 24))
    # locating socket for the foot top
    cuts.append(box(-7.2, 7.2, -6.2, 6.2, BASE_Z0 - 1, BASE_Z0 + 0.8))
    return diff(body, cuts)

# ================================================================ Leg_C_2 (claw foot)
FOOT_T = 12.0

def foot_profile():
    """Claw outline in the (x, z) plane of the knee frame (x outward, z up)."""
    z_top = BASE_Z0 + 0.8          # sits in the 0.8 socket
    tip = np.array([-6.0, -TIBIA_TIP])
    # centre line: quadratic bezier bulging outward
    p0, p1, p2 = np.array([0.0, z_top - 4]), np.array([16.0, -62.0]), tip
    ts = np.linspace(0, 1, 40)
    cl = np.array([(1 - t) ** 2 * p0 + 2 * (1 - t) * t * p1 + t ** 2 * p2 for t in ts])
    w = np.linspace(9.5, 3.4, 40)          # half width
    d = np.gradient(cl, axis=0)
    nrm = np.stack([-d[:, 1], d[:, 0]], 1)
    nrm /= np.linalg.norm(nrm, axis=1)[:, None]
    left = cl + nrm * w[:, None]
    right = cl - nrm * w[:, None]
    pts = np.vstack([left, right[::-1]])
    from manifold3d import FillRule
    beam = CrossSection([pts], FillRule.NonZero)
    beam = beam ^ rect(-50, 50, -200, BASE_Z0 - 0.01)
    tipc = circ(3.0, tip[0], tip[1], 32)
    block = rect(-7.0, 7.0, z_top - 9, z_top)
    return CrossSection.batch_boolean([beam, tipc, block], __import__('manifold3d').OpType.Add)

def leg_c2():
    prof = foot_profile()
    body = xz_extrude(prof, -FOOT_T / 2, FOOT_T / 2)
    # narrow the top block to the socket (18 x 12)
    cuts = []
    for (fx, fy) in FOOT_SCREWS:
        cuts.append(cyl(INS_R, BASE_Z0 + 0.8 - INS_DEPTH, BASE_Z0 + 2, fx, fy, 24))
    # lightening slot in the upper claw
    return diff(body, cuts)

# ================================================================ Body
HEX_R = 56.0
WALL_T = 2.0
FLOOR_Z0, FLOOR_Z1 = CAR_Z0, CAR_Z0 + 3.0     # -25 .. -22
LEG_ANGLES = [30 + 60 * i for i in range(6)]
PCA_HOLES = [(sx * 28.0 - 6.0, cy + sy * 9.5) for cy in (14.0, -14.0) for sx in (1, -1) for sy in (1, -1)]
LID_POST_ANG = [60, 120, 240, 300]
LID_POST_R = 41.0
LID_TOP = 28.0

def hexagon(r, rot=30):
    from manifold3d import FillRule
    a = np.radians(np.arange(6) * 60 + rot)
    return CrossSection([np.stack([r * np.cos(a), r * np.sin(a)], 1)], FillRule.NonZero)

def leg_frame(i):
    th = LEG_ANGLES[i]
    return M(rotz(th), [R_COXA * np.cos(np.radians(th)), R_COXA * np.sin(np.radians(th)), 0])

def body():
    outer = hexagon(HEX_R).offset(3, JoinType.Round, circular_segments=24).offset(-3, JoinType.Round, circular_segments=24)
    inner = outer.offset(-WALL_T, JoinType.Round, circular_segments=24)
    tub = outer.extrude(0 - FLOOR_Z0).translate([0, 0, FLOOR_Z0]) - \
        inner.extrude(40).translate([0, 0, FLOOR_Z1])
    parts = [tub]
    for i in range(6):
        parts.append(apply(carrier_solid(), leg_frame(i)))
    # PCA9685 standoffs
    for (x, y) in PCA_HOLES:
        parts.append(cyl(3.2, FLOOR_Z1 - 0.1, FLOOR_Z1 + 4.0, x, y, 32))
    # lid posts (merge into wall)
    for a in LID_POST_ANG:
        x, y = LID_POST_R * np.cos(np.radians(a)), LID_POST_R * np.sin(np.radians(a))
        parts.append(cyl(3.5, FLOOR_Z1 - 0.1, LID_TOP - 2.0, x, y, 32))
        rx, ry = 47.0 * np.cos(np.radians(a)), 47.0 * np.sin(np.radians(a))
        rib = Manifold.batch_hull([cyl(1.0, FLOOR_Z1, 0, x, y, 16), cyl(1.0, FLOOR_Z1, 0, rx, ry, 16)])
        parts.append(rib)
    # ESP32-C3 SuperMini fence (front, USB facing +x)
    c3x0, c3x1, c3y0, c3y1 = 25.8, 46.4, -21.6, -3.2
    fence = rbox(c3x0 - 1.4, c3x1, c3y0 - 1.4, c3y1 + 1.4, FLOOR_Z1 - 0.1, FLOOR_Z1 + 2.5, 0.8) - \
        box(c3x0, c3x1 + 5, c3y0, c3y1, FLOOR_Z1, 10)
    parts.append(fence)
    b = union(parts)
    cuts = []
    for i in range(6):
        cuts += placed(carrier_cuts(), leg_frame(i))
    for (x, y) in PCA_HOLES:
        cuts.append(cyl(INS_R, FLOOR_Z1 + 4.0 - INS_DEPTH, FLOOR_Z1 + 5, x, y, 24))
    for a in LID_POST_ANG:
        x, y = LID_POST_R * np.cos(np.radians(a)), LID_POST_R * np.sin(np.radians(a))
        cuts.append(cyl(INS_R, LID_TOP - 2.0 - INS_DEPTH, LID_TOP, x, y, 24))
    # USB-C opening for the C3 in the front wall
    cuts.append(rbox(40, 60, (c3y0 + c3y1) / 2 - 5.0, (c3y0 + c3y1) / 2 + 5.0, FLOOR_Z1 + 0.6, FLOOR_Z1 + 6.6, 1.0))
    cuts.append(box(44, 60, c3y0, c3y1, FLOOR_Z1 - 0.01, FLOOR_Z1 + 1.4))
    # zip-tie slots for the UBEC (front-left) and wiring
    for (x, y) in ((33.0, 6.0), (33.0, 24.0), (42.0, 6.0), (42.0, 24.0)):
        cuts.append(box(x - 1.8, x + 1.8, y - 1.0, y + 1.0, FLOOR_Z0 - 1, FLOOR_Z1 + 1))
    # lightening windows in the floor between the PCA boards
    for y0, y1 in ((-30.0, -27.0), (27.0, 30.0)):
        pass
    for (cx, cy) in ((-6.0, 0.0),):
        cuts.append(rbox(cx - 20, cx + 20, cy - 2.5, cy + 2.5, FLOOR_Z0 - 1, FLOOR_Z1 + 1, 2.0))
    for (cx, cy) in ((-6.0, 14.0), (-6.0, -14.0)):
        cuts.append(rbox(cx - 18, cx + 18, cy - 5.0, cy + 5.0, FLOOR_Z0 - 1, FLOOR_Z1 + 1, 3.0))
    return diff(b, cuts)

# ================================================================ Lid (Upper_Body)
LID_CLIP_R = 51.5      # keeps the lid out of the coxa horn sweep

def lid():
    outer2d = hexagon(HEX_R).offset(3, JoinType.Round, circular_segments=24).offset(-3, JoinType.Round, circular_segments=24)
    clip = circ(LID_CLIP_R, 0, 0, 128)
    o = outer2d ^ clip
    shell_o = o.extrude(LID_TOP - 4.0)
    top_cs = o.offset(-4.0, JoinType.Round, circular_segments=24)
    cap = Manifold.batch_hull([o.extrude(0.01).translate([0, 0, LID_TOP - 4.01]),
                               top_cs.extrude(0.01).translate([0, 0, LID_TOP - 0.01])])
    solid = shell_o + cap
    i2d = o.offset(-1.8, JoinType.Round, circular_segments=24)
    inner = i2d.extrude(LID_TOP - 4.0 + 0.01).translate([0, 0, -0.01])
    icap = Manifold.batch_hull([i2d.extrude(0.01).translate([0, 0, LID_TOP - 4.0]),
                                i2d.offset(-4.0, JoinType.Round, circular_segments=24).extrude(0.01).translate([0, 0, LID_TOP - 2.0])])
    shell = solid - inner - icap
    # locating lip that drops inside the body wall
    body_in = outer2d.offset(-WALL_T - 0.3, JoinType.Round, circular_segments=24) ^ circ(LID_CLIP_R - 2.2, 0, 0, 128)
    lip = (body_in - body_in.offset(-1.4, JoinType.Round, circular_segments=24)).extrude(3.0).translate([0, 0, -3.0])
    parts = [shell, lip]
    # post bosses under the top
    for a in LID_POST_ANG:
        x, y = LID_POST_R * np.cos(np.radians(a)), LID_POST_R * np.sin(np.radians(a))
        parts.append(cyl(3.5, LID_TOP - 2.0, LID_TOP - 0.5, x, y, 32))
    L = union(parts)
    cuts = []
    for a in LID_POST_ANG:
        x, y = LID_POST_R * np.cos(np.radians(a)), LID_POST_R * np.sin(np.radians(a))
        cuts.append(cyl(1.15, LID_TOP - 5, LID_TOP + 1, x, y, 20))
    # cable notches at every leg + lid lip gaps there
    for a in LEG_ANGLES:
        m = M(rotz(a), [0, 0, 0])
        cuts.append(apply(box(35, 60, -7, 7, -4, 7), m))
    # battery strap slots (on top) and battery lead hole
    for y in (-16.0, 16.0):
        cuts.append(box(-12.0, 12.0, y - 1.6, y + 1.6, LID_TOP - 6, LID_TOP + 1))
    cuts.append(rbox(-30.0, -18.0, -5.0, 5.0, LID_TOP - 6, LID_TOP + 1, 2.0))
    # power switch (KCD11 style 19 x 13) in the back face
    cuts.append(box(-60, -40, -9.6, 9.6, 6.0, 19.2))
    return diff(L, cuts)

if __name__ == '__main__':
    import trimesh
    out = '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work/stl/'
    import os; os.makedirs(out, exist_ok=True)
    fns = dict(Leg_A=leg_a, Leg_B=leg_b, Leg_C_1=leg_c1, Leg_C_2=leg_c2, Body=body, Upper_Body=lid,
               Shaft=shaft_part, Washer=washer_part)
    names = sys.argv[1:] or list(fns)
    for n in names:
        m = fns[n]()
        mesh = m.to_mesh()
        tm = trimesh.Trimesh(mesh.vert_properties[:, :3], mesh.tri_verts, process=False)
        tm.export(out + n + '.stl')
        print(n, m.status(), 'vol cm3 %.1f' % (m.volume() / 1000), 'bounds', np.round(tm.bounds, 1).tolist(), 'genus', m.genus())
