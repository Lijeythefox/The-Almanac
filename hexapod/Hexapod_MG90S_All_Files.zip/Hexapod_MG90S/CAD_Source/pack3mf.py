import sys, os, zipfile, uuid
sys.path.insert(0, '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work')
from parts import *
from truss import leg_a_t, leg_b_t, leg_c1_t, leg_c2_t, body_t, lid_t

SRC = '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/hex_src/x/'
OUT = sys.argv[1]
BED = 256.0
PITCH = BED * 1.2
COLS = 3

def R(rot):
    return M(rot, [0, 0, 0])

# name, builder, print rotation, count
SPECS = {
    'Body':        (body_t,      np.eye(3), 1),
    'Upper_Body':  (lid_t,       rotx(180), 1),
    'Leg_A':       (leg_a_t,     rotx(90),  6),
    'Leg_B':       (leg_b_t,     np.eye(3), 6),
    'Leg_C_1':     (leg_c1_t,    np.eye(3), 6),
    'Leg_C_2':     (leg_c2_t,    rotx(90),  6),
    'Shaft':       (shaft_part,  np.eye(3), 18),
    'Washer':      (washer_part, np.eye(3), 18),
}
PLATES = [
    ('Body + pivots', [('Body', 1), ('Shaft', 18), ('Washer', 18)]),
    ('Lid + feet', [('Upper_Body', 1), ('Leg_C_2', 6)]),
    ('Coxa brackets', [('Leg_A', 6)]),
    ('Femurs', [('Leg_B', 6)]),
    ('Tibia brackets', [('Leg_C_1', 6)]),
]

meshes = {}
for n, (fn, rot, cnt) in SPECS.items():
    m = apply(fn(), R(rot))
    bb = m.bounding_box()
    m = m.translate([-(bb[0] + bb[3]) / 2, -(bb[1] + bb[4]) / 2, -bb[2]])
    m = m.simplify(0.001)
    meshes[n] = m
    print(n, np.round(m.bounding_box(), 1))

def footprint(n):
    b = meshes[n].bounding_box()
    return b[3] - b[0], b[4] - b[1]

def layout(items):
    """returns list of (name, x, y) on a BED x BED plate (centred at BED/2)."""
    out = []
    big = [(n, c) for n, c in items if n not in ('Shaft', 'Washer')]
    small = [(n, c) for n, c in items if n in ('Shaft', 'Washer')]
    # shelf packing for big parts
    gap = 6.0
    rows = []
    for n, c in big:
        w, h = footprint(n)
        if n == 'Body' or n == 'Upper_Body':
            rows.append([(n, w, h)])
            continue
        per_row = max(1, int((BED - 20 + gap) // (w + gap)))
        lst = [(n, w, h)] * c
        for i in range(0, len(lst), per_row):
            rows.append(lst[i:i + per_row])
    # stack rows vertically, centred
    tot_h = sum(max(h for _, _, h in r) for r in rows) + gap * (len(rows) - 1)
    y = BED / 2 + tot_h / 2
    pos = []
    for r in rows:
        rh = max(h for _, _, h in r)
        rw = sum(w for _, w, _ in r) + gap * (len(r) - 1)
        x = BED / 2 - rw / 2
        for n, w, h in r:
            pos.append((n, x + w / 2, y - rh / 2))
            x += w + gap
        y -= rh + gap
    # small parts in the free corners around the body
    if small:
        k = 0
        slots = []
        for cx in (14, 31, BED - 31, BED - 14):
            for j in range(12):
                slots.append((cx, 30 + j * 17))
        # remove slots clashing with the body footprint
        bw, bh = footprint('Body') if any(n == 'Body' for n, _ in big) else (0, 0)
        def free(px, py):
            return not (abs(px - BED / 2) < bw / 2 + 9 and abs(py - BED / 2) < bh / 2 + 9)
        slots = [s for s in slots if free(*s)]
        flat = [n for n, c in small for _ in range(c)]
        assert len(flat) <= len(slots), (len(flat), len(slots))
        for n, s in zip(flat, slots):
            pos.append((n, s[0], s[1]))
    return pos

def mesh_xml(m, oid):
    mm = m.to_mesh()
    v = mm.vert_properties[:, :3]
    t = mm.tri_verts
    vs = '\n'.join('     <vertex x="%.6f" y="%.6f" z="%.6f"/>' % tuple(p) for p in v)
    ts = '\n'.join('     <triangle v1="%d" v2="%d" v3="%d"/>' % tuple(f) for f in t)
    return ('<?xml version="1.0" encoding="UTF-8"?>\n<model unit="millimeter" xml:lang="en-US" '
            'xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02" '
            'xmlns:BambuStudio="http://schemas.bambulab.com/package/2021" '
            'xmlns:p="http://schemas.microsoft.com/3dmanufacturing/production/2015/06" requiredextensions="p">\n'
            ' <metadata name="BambuStudio:3mfVersion">1</metadata>\n <resources>\n'
            f'  <object id="{oid}" p:UUID="{uuid.uuid4()}" type="model">\n   <mesh>\n    <vertices>\n{vs}\n    </vertices>\n'
            f'    <triangles>\n{ts}\n    </triangles>\n   </mesh>\n  </object>\n </resources>\n <build/>\n</model>\n'), len(t)

# mesh sub-files: one per part type
sub_ids = {}
sub_files = {}
nid = 1
for n in SPECS:
    sub_ids[n] = nid
    xml, nf = mesh_xml(meshes[n], nid)
    sub_files[n] = (f'3D/Objects/{n}_{nid}.model', xml, nf)
    nid += 1

objects = []   # (top_id, name, plate_idx, x, y)
top = 100
for pi, (pname, items) in enumerate(PLATES):
    col, row = pi % COLS, pi // COLS
    ox, oy = col * PITCH, -row * PITCH
    for n, x, y in layout(items):
        objects.append((top, n, pi, ox + x, oy + y))
        top += 1

res = []
build = []
for oid, n, pi, x, y in objects:
    path, _, _ = sub_files[n]
    res.append(f'  <object id="{oid}" p:UUID="{uuid.uuid4()}" type="model">\n   <components>\n'
               f'    <component p:path="/{path}" objectid="{sub_ids[n]}" p:UUID="{uuid.uuid4()}" transform="1 0 0 0 1 0 0 0 1 0 0 0" />\n'
               f'   </components>\n  </object>')
    build.append(f'  <item objectid="{oid}" p:UUID="{uuid.uuid4()}" transform="1 0 0 0 1 0 0 0 1 {x:.4f} {y:.4f} 0" printable="1" />')

main = ('<?xml version="1.0" encoding="UTF-8"?>\n<model unit="millimeter" xml:lang="en-US" '
        'xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02" '
        'xmlns:BambuStudio="http://schemas.bambulab.com/package/2021" '
        'xmlns:p="http://schemas.microsoft.com/3dmanufacturing/production/2015/06" requiredextensions="p">\n'
        ' <metadata name="Application">BambuStudio-02.02.01.60</metadata>\n'
        ' <metadata name="BambuStudio:3mfVersion">1</metadata>\n'
        ' <metadata name="Title">MG90S Hexapod (ESP32)</metadata>\n'
        ' <metadata name="Designer">Elijah + Claude</metadata>\n'
        ' <resources>\n' + '\n'.join(res) + '\n </resources>\n'
        f' <build p:UUID="{uuid.uuid4()}">\n' + '\n'.join(build) + '\n </build>\n</model>\n')

rels = ('<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n' +
        '\n'.join(f' <Relationship Target="/{p}" Id="rel-{i+1}" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>'
                  for i, (p, _, _) in enumerate(sub_files.values())) + '\n</Relationships>\n')

PRETTY = {'Body': 'Body', 'Upper_Body': 'Lid (Upper_Body)', 'Leg_A': 'Leg_A coxa bracket', 'Leg_B': 'Leg_B femur',
          'Leg_C_1': 'Leg_C_1 tibia bracket', 'Leg_C_2': 'Leg_C_2 claw foot', 'Shaft': 'Shaft pivot pin', 'Washer': 'Washer 1mm'}
cfg = ['<?xml version="1.0" encoding="UTF-8"?>', '<config>']
counter = {}
for oid, n, pi, x, y in objects:
    counter[n] = counter.get(n, 0) + 1
    nm = f'{PRETTY[n]} {counter[n]}' if SPECS[n][2] > 1 else PRETTY[n]
    nf = sub_files[n][2]
    cfg += [f'  <object id="{oid}">', f'    <metadata key="name" value="{nm}"/>', '    <metadata key="extruder" value="1"/>',
            f'    <metadata face_count="{nf}"/>', f'    <part id="{sub_ids[n]}" subtype="normal_part">',
            f'      <metadata key="name" value="{nm}"/>', '      <metadata key="matrix" value="1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1"/>',
            '      <metadata key="source_object_id" value="0"/>', '      <metadata key="source_volume_id" value="0"/>',
            f'      <mesh_stat face_count="{nf}" edges_fixed="0" degenerate_facets="0" facets_removed="0" facets_reversed="0" backwards_edges="0"/>',
            '    </part>', '  </object>']
ident = 1000
for pi, (pname, items) in enumerate(PLATES):
    cfg += ['  <plate>', f'    <metadata key="plater_id" value="{pi+1}"/>', f'    <metadata key="plater_name" value="{pname}"/>',
            '    <metadata key="locked" value="false"/>']
    for oid, n, p2, x, y in objects:
        if p2 == pi:
            ident += 1
            cfg += ['    <model_instance>', f'      <metadata key="object_id" value="{oid}"/>',
                    '      <metadata key="instance_id" value="0"/>', f'      <metadata key="identify_id" value="{ident}"/>',
                    '    </model_instance>']
    cfg += ['  </plate>']
cfg += ['  <assemble>']
for oid, n, pi, x, y in objects:
    cfg += [f'   <assemble_item object_id="{oid}" instance_id="0" transform="1 0 0 0 1 0 0 0 1 {x:.4f} {y:.4f} 0" offset="0 0 0" />']
cfg += ['  </assemble>', '</config>']

with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('[Content_Types].xml', open(SRC + '[Content_Types].xml').read())
    z.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n'
               ' <Relationship Target="/3D/3dmodel.model" Id="rel-1" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>\n</Relationships>\n')
    z.writestr('3D/3dmodel.model', main)
    z.writestr('3D/_rels/3dmodel.model.rels', rels)
    for p, xml, _ in sub_files.values():
        z.writestr(p, xml)
    z.writestr('Metadata/model_settings.config', '\n'.join(cfg) + '\n')
    z.writestr('Metadata/project_settings.config', open(SRC + 'Metadata/project_settings.config').read())
    z.writestr('Metadata/slice_info.config', open(SRC + 'Metadata/slice_info.config').read())
print('objects', len(objects), 'written', OUT, os.path.getsize(OUT))
# dump plate layouts for preview
import json
json.dump([(oid, n, pi, x, y) for oid, n, pi, x, y in objects], open('/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work/layout.json', 'w'))
for n, m in meshes.items():
    mm = m.to_mesh()
    import trimesh
    trimesh.Trimesh(mm.vert_properties[:, :3], mm.tri_verts).export(f'/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work/stl/print_{n}.stl')

# ---------------- A1-ready STL export
import trimesh
OUTDIR = os.path.dirname(OUT) + '/Hexapod_MG90S_STL/'
os.makedirs(OUTDIR + 'Parts', exist_ok=True); os.makedirs(OUTDIR + 'Plates', exist_ok=True)
FN = {'Body': '01_Body_x1', 'Upper_Body': '02_Lid_Upper_Body_x1', 'Leg_A': '03_Leg_A_coxa_bracket_x6',
      'Leg_B': '04_Leg_B_femur_x6', 'Leg_C_1': '05_Leg_C_1_tibia_bracket_x6', 'Leg_C_2': '06_Leg_C_2_claw_foot_x6',
      'Shaft': '07_Shaft_pivot_pin_x18', 'Washer': '08_Washer_1mm_x18'}
def tm(m):
    mm = m.to_mesh()
    return trimesh.Trimesh(mm.vert_properties[:, :3].astype(float), mm.tri_verts, process=False)
for n, m in meshes.items():
    tm(m).export(OUTDIR + 'Parts/' + FN[n] + '.stl')
for pi, (pname, items) in enumerate(PLATES):
    ox, oy = (pi % COLS) * PITCH, -(pi // COLS) * PITCH
    ms = [meshes[n].translate([x - ox - BED / 2, y - oy - BED / 2, 0]) for oid, n, p2, x, y in objects if p2 == pi]
    plate = Manifold.batch_boolean(ms, __import__('manifold3d').OpType.Add)
    plate = plate.simplify(0.001)
    tm(plate).export(OUTDIR + 'Plates/' + f'Plate{pi+1}_' + pname.replace(' + ', '_and_').replace(' ', '_') + '.stl')
print('STLs in', OUTDIR)
