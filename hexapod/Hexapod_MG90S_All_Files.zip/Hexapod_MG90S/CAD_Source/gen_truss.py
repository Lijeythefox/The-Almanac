import sys; sys.path.insert(0,'/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work')
from truss import *
import trimesh
fns=dict(Leg_A=(leg_a,leg_a_t),Leg_B=(leg_b,leg_b_t),Leg_C_1=(leg_c1,leg_c1_t),Leg_C_2=(leg_c2,leg_c2_t),Body=(body,body_t),Upper_Body=(lid,lid_t))
for n,(f0,f1) in fns.items():
    a=f0(); b=f1()
    mm=b.to_mesh(); trimesh.Trimesh(mm.vert_properties[:,:3],mm.tri_verts).export(f'/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work/stl/T_{n}.stl')
    print(f'{n}: {a.volume()/1000:.1f} -> {b.volume()/1000:.1f} cm3 ({100*(1-b.volume()/a.volume()):.0f}% lighter)')
