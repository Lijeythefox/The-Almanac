import sys, os, time, subprocess, numpy as np
sys.path.insert(0, '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work')
from gait import *
from assembly import T
import imageio_ffmpeg
from playwright.sync_api import sync_playwright

BASE = '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work/'
OUT = '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/out/hexapod_walk.mp4'
FPS = 30

guess = [np.array([0.0, 20.0, -20.0]) for _ in range(6)]
def pose(t):
    """t in gait cycles -> (angles per leg, body x)"""
    out = []
    for i in range(6):
        ph = (t + (0.0 if i in TRIPOD else 0.5)) % 1.0
        off, sw = foot_offset(ph)
        q, err = ik(i, home(i) + np.array([off[0], 0, off[2]]), guess[i])
        guess[i] = q
        out.append(q)
    return out, t * 2 * STRIDE

GROUP_COL = {True: '#e07b2a', False: '#2f7fd1'}
objs = [('/stl/T_Body.stl', '#f1f1ee'), ('/stl/T_Upper_Body.stl', '#e8e8e4')]
for i in range(6):
    for f in ('Leg_A', 'Leg_B', 'Leg_C_1'):
        objs.append((f'/stl/T_{f}.stl', '#f1f1ee'))
    objs.append(('/stl/T_Leg_C_2.stl', GROUP_COL[i in TRIPOD]))
    for _ in range(3):
        objs.append(('/stl/servo.stl', '#2b2b2e'))

def mats(angles, bx):
    Wd = T([bx, 0, BODY_H])
    ms = [Wd, Wd]
    for i in range(6):
        LA, LB, LC = leg_mats(i, *angles[i])
        ms += [Wd @ LA, Wd @ LB, Wd @ LC, Wd @ LC, Wd @ leg_frame(i) @ S1, Wd @ LA @ S2, Wd @ LB @ S3]
    return [m.tolist() for m in ms]

segments = [
    # (label, sub, cycles, speed factor, camera offset from body, target z)
    ('Tripod gait - real speed', '10 cm/s  |  0.8 s per cycle  |  40 mm stride, 22 mm step height', 4.0, 1.0, (330, -520, 260)),
    ('Tripod gait - 4x slow motion', 'Orange and blue tripods alternate: 3 feet always on the ground', 1.5, 0.25, (0, -560, 90)),
    ('Tripod gait - top view', 'Stance feet push in straight lines; swing feet follow a smooth cycloid arc', 2.0, 1.0, (-40, -60, 640)),
]

srv = subprocess.Popen(['python3', '-m', 'http.server', '8766', '-d', BASE], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(0.8)
os.makedirs(BASE + 'frames', exist_ok=True)
for f in os.listdir(BASE + 'frames'):
    os.remove(BASE + 'frames/' + f)
n = 0
try:
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader'])
        pg = b.new_page(viewport={'width': 1280, 'height': 720})
        pg.goto('http://localhost:8766/viewer/anim.html')
        pg.wait_for_function('window.READY===true', timeout=60000)
        pg.evaluate('(l)=>window.init(l)', [{'file': f, 'color': c} for f, c in objs])
        t_cyc = 0.0
        for lab, sub, cycles, spd, cam in segments:
            nfr = int(round(cycles * CYCLE / spd * FPS))
            for k in range(nfr):
                t = t_cyc + k / nfr * cycles
                ang, bx = pose(t)
                tgt = [bx, 0, 40]
                cp = [bx + cam[0], cam[1], cam[2]]
                pg.evaluate('([m,c,g,l,s])=>window.frame(m,c,g,l,s)', [mats(ang, bx), cp, tgt, lab, sub])
                pg.screenshot(path=BASE + f'frames/f{n:05d}.png')
                n += 1
            t_cyc += cycles
        b.close()
finally:
    srv.kill()
ff = imageio_ffmpeg.get_ffmpeg_exe()
subprocess.run([ff, '-y', '-loglevel', 'error', '-framerate', str(FPS), '-i', BASE + 'frames/f%05d.png',
                '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '20', '-movflags', '+faststart', OUT], check=True)
print('frames', n, 'video', OUT, os.path.getsize(OUT))
