import sys; sys.path.insert(0,'.')
from remote import *
zp=H_TOP-PLATE
comp={}
for k,(jx,jy) in enumerate(JOY):
    pcb=box(jx-17,jx+17,jy-13,jy+13,JOY_PCB_TOP-1.6,JOY_PCB_TOP)
    pins=box(jx+(17 if jx<0 else -21), jx+(21 if jx<0 else -17), jy-4, jy+4, JOY_PCB_TOP-10, JOY_PCB_TOP) # header (approx)
    gim=box(jx-8,jx+8,jy-8,jy+8,JOY_PCB_TOP,JOY_PCB_TOP+10.5)
    stick=cyl(4,JOY_PCB_TOP+10.5,JOY_PCB_TOP+28,jx,jy)
    comp[f'joy{k}']=union([pcb,gim,stick])
cy_=(SLIDER_Y0+SLIDER_Y1)/2
comp['slider']=union([box(-4.5,4.5,cy_-37.5,cy_+37.5,zp-7.5,zp), box(-1,1,cy_-2,cy_+2,zp,zp+10)])
comp['knob']=union([cyl(8,zp-10,zp,*KNOB),cyl(3,zp,zp+20,*KNOB)])
comp['rocker']=box(SWITCH[0]-6.5,SWITCH[0]+6.5,SWITCH[1]-9.5,SWITCH[1]+9.5,zp-15,zp+3)
comp['button']=cyl(6,zp-18,zp+3,*BUTTON)
x0,x1,y0,y1=ESP
comp['esp32']=union([box(x0,x1,y0,y1,11,12.6),box(x0+4,x1-4,y0+2,y1-8,12.6,15.6),box(x0,x0+2.6,y0+2,y1-2,3.0,11),box(x1-2.6,x1,y0+2,y1-2,3.0,11)])
tx0,tx1,ty0,ty1=TP
comp['tp4056']=box(tx0,tx1,ty0,ty1,PLATE,PLATE+5)
bx0,bx1,by0,by1=BATT
comp['battery']=box(bx0,bx1,by0,by1,PLATE,PLATE+10.5)
T_=top_shell(); B_=bottom_shell()
for n,c in comp.items():
    print(n.ljust(8),'vs top',round((c^T_).volume(),1),' vs bottom',round((c^B_).volume(),1))
names=list(comp)
for i in range(len(names)):
    for j in range(i+1,len(names)):
        v=(comp[names[i]]^comp[names[j]]).volume()
        if v>0.1: print('clash',names[i],names[j],round(v,1))
print('shells overlap', round((T_^B_).volume(),1))
import trimesh
for n,c in comp.items():
    mm=c.to_mesh(); trimesh.Trimesh(mm.vert_properties[:,:3],mm.tri_verts).export(f'stl/rc_{n}.stl')
