import sys
sys.path.insert(0, '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work')
from parts import *
from manifold3d import FillRule, OpType

RIB = 2.4      # rib width between holes (≈5-6 extrusion lines at 0.42)
BORDER = 2.4   # solid margin kept around every edge / feature
RR = 1.0       # corner radius of the triangular windows

def frame(normal_axis, w_sign=1, rot_deg=0.0, origin=(0, 0, 0), base=None):
    """Panel frame: panel coords (u, v, w) -> part coords. w along the panel normal."""
    if normal_axis == 'z':
        R = np.eye(3)
    elif normal_axis == 'y':
        R = np.array([[1, 0, 0], [0, 0, 1], [0, -1, 0]], float).T  # u=x, v=z, w=-y ... fixed below
        R = np.column_stack([[1, 0, 0], [0, 0, 1], [0, -1, 0]])     # u->x, v->z, w->-y
        R = np.column_stack([[1, 0, 0], [0, 0, -1], [0, 1, 0]])     # u->x, v->-z, w->+y (right handed)
    elif normal_axis == 'x':
        R = np.column_stack([[0, 1, 0], [0, 0, 1], [1, 0, 0]])      # u->y, v->z, w->x
    m = M(R, origin)
    if base is not None:
        m = base @ m
    return m

def tri_grid(bounds, s, angle):
    """Alternating up/down equilateral triangles in a frame rotated by `angle`;
    bounds are given in that rotated frame; returned polygons are in the panel frame."""
    u0, v0, u1, v1 = bounds
    cu, cv = (u0 + u1) / 2, (v0 + v1) / 2
    h = s * np.sqrt(3) / 2
    nrow = int(np.ceil((v1 - v0) / h / 2)) + 1
    ncol = int(np.ceil((u1 - u0) / s / 2)) + 2
    ca, sa = np.cos(np.radians(angle)), np.sin(np.radians(angle))
    tris = []
    for j in range(-nrow, nrow + 1):
        y0, y1 = cv + j * h - h / 2, cv + j * h + h / 2
        off = (j % 2) * s / 2
        for i in range(-ncol, ncol + 1):
            x = cu + i * s + off
            up = np.array([[x - s / 2, y0], [x + s / 2, y0], [x, y1]])
            dn = np.array([[x, y1], [x + s, y1], [x + s / 2, y0]])
            for t in (up, dn):
                tris.append(np.stack([t[:, 0] * ca - t[:, 1] * sa, t[:, 0] * sa + t[:, 1] * ca], 1))
    return tris

def shrink_round(cs, d, rr=RR):
    return cs.offset(-(d + rr), JoinType.Miter).offset(rr, JoinType.Round, circular_segments=12)

def panel_holes(part, F, w0, w1, s, angle=0.0, clip=None, minfrac=0.35, rib=RIB, border=BORDER):
    Finv = np.linalg.inv(F)
    loc = apply(part, Finv)
    sl = lambda w: loc.slice(w)
    full = sl(w0 + 0.15) ^ sl(w1 - 0.15) ^ sl((w0 + w1) / 2)
    attached = sl(w1 + 0.35) + sl(w0 - 0.35)
    allowed = full.offset(-border, JoinType.Round, circular_segments=16) - \
        attached.offset(border, JoinType.Round, circular_segments=16)
    if clip is not None:
        allowed = allowed ^ clip
    if allowed.is_empty():
        return None, 0
    rb = allowed.rotate(-angle).bounds()
    hv = rb[3] - rb[1]
    # narrow strip -> one row of Warren-truss triangles filling the strip height
    L = rb[2] - rb[0]
    if hv < 1.9 * s * np.sqrt(3) / 2:
        s = max(min((hv + 1.5 * rib) / (np.sqrt(3) / 2), L / 1.6), 2 * rib + 4)
    holes = []
    full_area = (np.sqrt(3) / 4) * max(s - rib * np.sqrt(3), 0.1) ** 2
    for t in tri_grid(rb, s, angle):
        tc = CrossSection([t], FillRule.NonZero)
        tc = tc.offset(-rib / 2, JoinType.Miter)
        if tc.is_empty():
            continue
        piece = tc ^ allowed
        for pc in piece.decompose():
            if pc.area() >= minfrac * full_area:
                er = pc.offset(-RR - 0.3, JoinType.Miter)
                comps = er.decompose()
                if not comps:
                    continue
                er = max(comps, key=lambda c: c.area())
                pr = er.offset(RR + 0.3, JoinType.Round, circular_segments=12)
                pr = pr.simplify(0.05)
                if not pr.is_empty() and pr.area() > 6.0:
                    holes.append(pr)
    if not holes:
        return None, 0
    hcs = CrossSection.batch_boolean(holes, OpType.Add).simplify(0.05)
    prism = hcs.extrude(w1 - w0 + 0.4).translate([0, 0, w0 - 0.2])
    return apply(prism, F), len(holes)

def cut_panels(part, panels, verbose=True, name=''):
    cuts = []
    for p in panels:
        h, n = panel_holes(part, **p)
        if verbose:
            print(f'  {name}: panel w=[{p["w0"]:.1f},{p["w1"]:.1f}] -> {n} windows')
        if h is not None:
            cuts.append(h)
    return diff(part, cuts) if cuts else part

# ------------------------------------------------------------------ parts
def leg_a_t():
    p = leg_a()
    Fx = frame('x')
    Fz = frame('z')
    panels = [
        dict(F=Fx, w0=X_FEMUR + 6.35, w1=X_FEMUR + 8.35, s=13.0, angle=90),     # outer servo wall
        dict(F=Fx, w0=X_FEMUR - 8.35, w1=X_FEMUR - 6.35, s=13.0, angle=90),     # inner wall / web
    ]
    return cut_panels(p, panels, name='Leg_A')

def leg_b_t():
    p = leg_b()
    Fz = frame('z')
    Fy = frame('y')
    panels = [
        dict(F=Fz, w0=-8.35, w1=8.35, s=11.0, angle=90, clip=rect(19.7, 28.3, -30, 30)),   # fork-to-box neck (vertical holes)
        dict(F=Fz, w0=6.35, w1=8.35, s=12.0, angle=0, clip=rect(28.6, 70, -30, 30)),       # servo box top wall
        dict(F=Fz, w0=-8.35, w1=-6.35, s=12.0, angle=0, clip=rect(28.6, 70, -30, 30)),     # servo box bottom wall
        dict(F=Fy, w0=CAR_YLO, w1=CAR_YLO + FLOOR, s=11.0, angle=0, clip=rect(28.6, 70, -30, 30)),  # pivot side
        dict(F=Fy, w0=HORN_Y[0], w1=HORN_Y[1], s=10.0, angle=0, clip=rect(-30, 30, -30, 30)),  # horn fork arm
        dict(F=Fy, w0=PIV_Y[0], w1=PIV_Y[1], s=10.0, angle=0, clip=rect(-30, 30, -30, 30)),    # pivot fork arm
    ]
    return cut_panels(p, panels, name='Leg_B')

def leg_c1_t():
    p = leg_c1()
    Fy = frame('y')
    Fz = frame('z')
    panels = [
        dict(F=Fy, w0=HORN_Y[0], w1=HORN_Y[1], s=12.0, angle=0, clip=rect(-20, 20, 13.0, 40), border=2.0),
        dict(F=Fy, w0=PIV_Y[0], w1=PIV_Y[1], s=12.0, angle=0, clip=rect(-20, 20, 13.0, 40), border=2.0),
        dict(F=Fz, w0=BASE_Z0 + 0.8, w1=BASE_Z1, s=10.0, angle=0, clip=rect(-30, 30, -18.5, 18.5)),
    ]
    return cut_panels(p, panels, name='Leg_C_1')

def foot_truss_holes():
    """Warren truss along the curved claw (vertical holes when printed flat)."""
    z_top = BASE_Z0 + 0.8
    tip = np.array([-6.0, -TIBIA_TIP])
    p0, p1, p2 = np.array([0.0, z_top - 4]), np.array([16.0, -62.0]), tip
    ts = np.linspace(0, 1, 400)
    cl = np.array([(1 - t) ** 2 * p0 + 2 * (1 - t) * t * p1 + t ** 2 * p2 for t in ts])
    w = np.linspace(9.5, 3.4, 400)
    d = np.gradient(cl, axis=0)
    nrm = np.stack([-d[:, 1], d[:, 0]], 1); nrm /= np.linalg.norm(nrm, axis=1)[:, None]
    seg = np.r_[0, np.cumsum(np.linalg.norm(np.diff(cl, axis=0), axis=1))]
    s_start, s_end = 9.0, seg[-1] - 12.0          # keep top block (screws) and the tip solid
    stations = np.linspace(s_start, s_end, 6)
    idx = [int(np.searchsorted(seg, s)) for s in stations]
    inset = 1.9
    nodes = []
    for k, i in enumerate(idx):
        side = 1 if k % 2 == 0 else -1
        ww = max(w[i] - inset, 0.4)
        nodes.append(cl[i] + side * nrm[i] * ww)
    holes = []
    beam_in = foot_profile().offset(-inset, JoinType.Round, circular_segments=12)
    for k in range(len(nodes) - 2):
        t = np.array([nodes[k], nodes[k + 1], nodes[k + 2]])
        tc = CrossSection([t], FillRule.NonZero)
        tc = tc.offset(-RIB / 2 - 0.6, JoinType.Miter).offset(0.6, JoinType.Round, circular_segments=12)
        tc = tc ^ beam_in
        if not tc.is_empty() and tc.area() > 5:
            holes.append(tc)
    hcs = CrossSection.batch_boolean(holes, OpType.Add)
    return xz_extrude(hcs, -FOOT_T / 2 - 1, FOOT_T / 2 + 1), len(holes)

def leg_c2_t():
    p = leg_c2()
    h, n = foot_truss_holes()
    print(f'  Leg_C_2: {n} windows')
    return p - h

def body_t():
    p = body()
    Fz = frame('z')
    panels = [dict(F=Fz, w0=FLOOR_Z0, w1=FLOOR_Z1, s=21.0, angle=0, clip=circ(60, 0, 0, 96))]
    # perimeter walls: normals at 0, 60, ... (edge mid-points)
    r_in = HEX_R * np.cos(np.radians(30)) - WALL_T
    for a in range(0, 360, 60):
        F = M(rotz(a), [0, 0, 0]) @ frame('x')
        panels.append(dict(F=F, w0=r_in, w1=r_in + WALL_T, s=11.0, angle=0,
                           clip=rect(-30, 30, FLOOR_Z1, -0.0)))
    # coxa servo box side walls (both sides) for every leg
    for i in range(6):
        base = leg_frame(i)
        for (y0, y1) in ((SW / 2 + CL, CAR_Y), (-CAR_Y, -(SW / 2 + CL))):
            F = base @ M(np.column_stack([[1, 0, 0], [0, 0, 1], [0, -1, 0]]), [0, 0, 0])
            # this frame has w -> -y; convert range
            panels.append(dict(F=F, w0=-y1, w1=-y0, s=10.0, angle=0, clip=rect(-30, 30, CAR_Z0 + 3.5, -3.0)))
    return cut_panels(p, panels, name='Body')

def lid_t():
    p = lid()
    Fz = frame('z')
    panels = [dict(F=Fz, w0=LID_TOP - 2.0, w1=LID_TOP, s=21.0, angle=0)]
    return cut_panels(p, panels, name='Upper_Body')
