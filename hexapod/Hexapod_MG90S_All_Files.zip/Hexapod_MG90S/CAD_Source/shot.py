import json, sys, subprocess, time, os, numpy as np
from playwright.sync_api import sync_playwright
BASE='/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work/'
def shots(jobs):
    """jobs: list of (scene_dict, out_png)"""
    srv=subprocess.Popen(['python3','-m','http.server','8765','-d',BASE],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    time.sleep(0.8)
    try:
        with sync_playwright() as p:
            b=p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader'])
            for i,(sc,out) in enumerate(jobs):
                fn=f'viewer/scene_{i}.json'; json.dump(sc,open(BASE+fn,'w'))
                pg=b.new_page(viewport={'width':sc.get('w',1000),'height':sc.get('h',800)})
                pg.on('console', lambda m: print('console', m.text))
                pg.goto(f'http://localhost:8765/viewer/index.html?scene=/{fn}')
                pg.wait_for_function('window.DONE===true',timeout=120000)
                pg.screenshot(path=BASE+out); pg.close()
            b.close()
    finally:
        srv.kill()
