import numpy as np
from manifold3d import Manifold, CrossSection, JoinType

N = 64

def box(x0, x1, y0, y1, z0, z1):
    return Manifold.cube([x1 - x0, y1 - y0, z1 - z0]).translate([x0, y0, z0])

def cyl(r, z0, z1, x=0.0, y=0.0, n=N):
    return Manifold.cylinder(z1 - z0, r, r, n).translate([x, y, z0])

def rbox(x0, x1, y0, y1, z0, z1, r):
    cs = CrossSection.square([x1 - x0 - 2 * r, y1 - y0 - 2 * r]).translate([x0 + r, y0 + r])
    cs = cs.offset(r, JoinType.Round, circular_segments=32)
    return cs.extrude(z1 - z0).translate([0, 0, z0])

def union(parts):
    parts = [p for p in parts if p is not None]
    return Manifold.batch_boolean(parts, __import__('manifold3d').OpType.Add)

def diff(a, cuts):
    cuts = [c for c in cuts if c is not None]
    if not cuts:
        return a
    return a - union(cuts)

def poly_extrude(pts, z0, z1):
    cs = CrossSection([np.asarray(pts, float)])
    return cs.extrude(z1 - z0).translate([0, 0, z0])

def hull2d_extrude(cs_list, z0, z1):
    return CrossSection.batch_hull(cs_list).extrude(z1 - z0).translate([0, 0, z0])

def circ(r, x=0, y=0, n=N):
    return CrossSection.circle(r, n).translate([x, y])

def rect(x0, x1, y0, y1):
    return CrossSection.square([x1 - x0, y1 - y0]).translate([x0, y0])

def M(R, t):
    """4x4 from rotation columns R (3x3) and translation t"""
    m = np.eye(4)
    m[:3, :3] = np.asarray(R, float)
    m[:3, 3] = t
    return m

def apply(man, m):
    return man.transform(np.asarray(m, float)[:3, :])

def rotz(deg):
    a = np.radians(deg); c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])

def roty(deg):
    a = np.radians(deg); c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])

def rotx(deg):
    a = np.radians(deg); c, s = np.cos(a), np.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])

# ---------------------------------------------------------------- MG90S
# Servo frame S: origin = output shaft axis on the TOP face of the mounting tabs.
# +z = shaft direction. Body length along x; shaft is near the +x end.
SL, SW = 22.8, 12.2          # body length / width
E_SHAFT = 5.9                # shaft centre to near end face
TAB_SPAN, TAB_T = 32.3, 2.5  # tab tip-to-tip, tab thickness
HOLE_PITCH = 27.5            # tab screw hole spacing
CL = 0.25                    # clearance per side
DEPTH = 21.5                 # tab top -> pocket floor (servo below tab is ~18.5)
FLOOR = 3.5                  # floor under servo (holds bearing)
WALL = 2.0
HORN_FACE = 13.0             # horn plate top above tab top (link arm inner face)
ARM_T = 3.5                  # link arm thickness
WASHER_T = 1.0
PIVOT_FACE = -(DEPTH + FLOOR + WASHER_T)   # -26.0 pivot arm inner face
SPAN_IN = HORN_FACE - PIVOT_FACE           # 39.0

BRG_OD, BRG_W = 8.0, 2.5     # MR85ZZ 5x8x2.5
BRG_SEAT_D = 8.15
PIN_D = 4.95

X_IN = -(SL - E_SHAFT)       # -16.9 inner end of servo body
X_OUT = E_SHAFT              # +5.9
X_C = (X_IN + X_OUT) / 2     # -5.5 body centre
HOLES_X = (X_C - HOLE_PITCH / 2, X_C + HOLE_PITCH / 2)  # -19.25, 8.25

CAR_X0 = X_C - TAB_SPAN / 2 - CL - 1.5   # carrier extents
CAR_X1 = X_C + TAB_SPAN / 2 + CL + 1.5
CAR_Y = SW / 2 + CL + WALL               # 8.35
CAR_Z0 = -(DEPTH + FLOOR)                # -25

def carrier_solid():
    return rbox(CAR_X0, CAR_X1, -CAR_Y, CAR_Y, CAR_Z0, 0.0, 1.5)

def carrier_cuts(both_notches=True):
    """Everything removed from a part that holds a servo (S frame)."""
    c = []
    py = SW / 2 + CL
    # body pocket (open upward)
    c.append(box(X_IN - CL, X_OUT + CL, -py, py, -DEPTH, 40))
    # flush tab recess
    c.append(box(X_C - TAB_SPAN / 2 - CL, X_C + TAB_SPAN / 2 + CL, -py, py, -TAB_T, 40))
    # M2.5 self-tapping pilots (2.1 mm) 6.5 mm deep (use M2.5x6 screws)
    for hx in HOLES_X:
        c.append(cyl(1.05, -6.5, 1, hx, 0, 24))
    # cable exit: centred slot straight out through the END wall (the MG90S lead leaves the
    # end face, low down). 4.2 mm wide, from the pocket floor up to 1.5 mm below the screw pilot.
    # Thread the plug out through the slot first (stand it on its edge), then lower the servo in.
    SLOT_W, SLOT_TOP = 4.2, -8.0
    ends = [(+1, X_OUT + CL), (-1, X_IN - CL)] if both_notches else [(-1, X_IN - CL)]
    for sgn, xe in ends:
        if sgn > 0:
            c.append(box(xe - 0.01, CAR_X1 + 1, -SLOT_W / 2, SLOT_W / 2, -DEPTH - 0.01, SLOT_TOP))
        else:
            c.append(box(CAR_X0 - 1, xe + 0.01, -SLOT_W / 2, SLOT_W / 2, -DEPTH - 0.01, SLOT_TOP))
    # bearing seat from the outside of the floor + pin clearance
    c.append(cyl(BRG_SEAT_D / 2, CAR_Z0 - 1, CAR_Z0 + BRG_W + 0.1, 0, 0))
    c.append(cyl(3.0, CAR_Z0, -DEPTH + 0.5, 0, 0))
    # keep everything above the tab plane clear (case top, gear tower, horn)
    c.append(box(X_IN - 0.8, X_OUT + 0.8, -py - 0.4, py + 0.4, 0, 9))
    c.append(cyl(6.6, 0, 11, 0, 0))
    c.append(cyl(17.5, 8.0, HORN_FACE - 0.01, 0, 0))
    return c

def servo_envelope():
    """Rough MG90S + horn for interference checks (S frame)."""
    parts = [box(X_IN, X_OUT, -SW / 2, SW / 2, -19.0, 4.5),
             box(X_C - TAB_SPAN / 2, X_C + TAB_SPAN / 2, -SW / 2, SW / 2, -TAB_T, 0),
             cyl(SW / 2 - 0.3, 4.5, 8.2, 0, 0),
             cyl(3.5, 8.2, 11.4, 0, 0),
             box(-16.5, 16.5, -2.8, 2.8, 11.4, 13.0)]
    return union(parts)

# horn arm features (S frame) – the arm occupies z in [HORN_FACE, HORN_FACE+ARM_T]
def horn_arm_cuts(dir_deg=0.0):
    c = [cyl(2.75, HORN_FACE - 1, HORN_FACE + ARM_T + 1, 0, 0)]
    for s in (+1, -1):
        sl = CrossSection.batch_hull([circ(1.15, s * 5.5, 0, 24), circ(1.15, s * 10.5, 0, 24)])
        c.append(sl.extrude(ARM_T + 2).translate([0, 0, HORN_FACE - 1]))
    return [m.rotate([0, 0, dir_deg]) for m in c]

SHAFT_DISC_D, SHAFT_DISC_T = 14.0, 2.0
SHAFT_SCREW_R = 4.9

def pivot_arm_cuts():
    zo = PIVOT_FACE - ARM_T          # outer face of pivot arm
    c = [cyl(SHAFT_DISC_D / 2 + 0.2, zo - 1, zo + SHAFT_DISC_T, 0, 0),
         cyl(2.7, zo - 1, PIVOT_FACE + 1, 0, 0)]
    for s in (+1, -1):
        c.append(cyl(0.85, zo - 1, PIVOT_FACE + 0.01, s * SHAFT_SCREW_R, 0, 20))
    return c

def shaft_part():
    """Pivot pin: disc sits in the arm's outer recess, pin goes through arm,
    washer and MR85ZZ bearing. Modelled disc-down (print orientation)."""
    pin_len = (ARM_T - SHAFT_DISC_T) + WASHER_T + BRG_W + 1.0
    d = cyl(SHAFT_DISC_D / 2, 0, SHAFT_DISC_T)
    p = cyl(PIN_D / 2, SHAFT_DISC_T - 0.01, SHAFT_DISC_T + pin_len)
    ch = Manifold.cylinder(0.6, PIN_D / 2, PIN_D / 2 - 0.5, N).translate([0, 0, SHAFT_DISC_T + pin_len - 0.6])
    p = p - box(-5, 5, -5, 5, SHAFT_DISC_T + pin_len - 0.6, 99) + ch
    s = d + p
    holes = [cyl(1.15, -1, 5, s_ * SHAFT_SCREW_R, 0, 20) for s_ in (1, -1)]
    return diff(s, holes)

def washer_part():
    return cyl(3.3, 0, WASHER_T) - cyl(2.65, -1, 2)

# helpers to place S frame features
def placed(items, m):
    if isinstance(items, list):
        return [apply(i, m) for i in items]
    return apply(items, m)
