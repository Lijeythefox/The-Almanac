import re, numpy as np, trimesh
SRC='/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/hex_src/x/3D/Objects/'
FILES={'Body':75,'Leg_A':172,'Leg_B':161,'Leg_C_1':54,'Leg_C_2':4,'Shaft':99,'Taban':227,'Upper_Body':78,'Ust_Kapak':228,'Washer':100}
def load(name):
    s=open(SRC+f'object_{FILES[name]}.model').read()
    v=np.array(re.findall(r'<vertex x="([^"]+)" y="([^"]+)" z="([^"]+)"',s),float)
    t=np.array(re.findall(r'<triangle v1="(\d+)" v2="(\d+)" v3="(\d+)"',s),int)
    return trimesh.Trimesh(v,t,process=True)
