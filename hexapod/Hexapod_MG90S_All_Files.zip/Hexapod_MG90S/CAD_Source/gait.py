import sys, json
sys.path.insert(0, '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work')
import numpy as np
from scipy.optimize import least_squares
from assembly import leg_mats, leg_frame, check_leg, P, ov, S1, S2, S3
from parts import R_COXA, LEG_ANGLES, TIBIA_TIP

TIP = np.array([-6.0, 0.0, -TIBIA_TIP - 3.0, 1.0])   # foot contact point in knee frame

# ---- gait parameters
BODY_H = 72.0        # ground -> body leg-frame z=0 (coxa tab plane)
REACH = 70.0         # foot radial distance from coxa axis at home
STRIDE = 40.0        # foot travel per stance (mm)
LIFT = 22.0          # swing height (mm)
CYCLE = 0.8          # seconds per full gait cycle
DUTY = 0.5           # tripod
TRIPOD = [0, 2, 4]   # legs at 30, 150, 270 deg  vs  [1, 3, 5] at 90, 210, 330
LIMITS = dict(a=(-35, 35), b=(-35, 75), c=(-55, 90))

def foot_world(i, ang):
    LA, LB, LC = leg_mats(i, *ang)
    return (LC @ TIP)[:3]

def home(i):
    th = np.radians(LEG_ANGLES[i])
    r = R_COXA + REACH
    return np.array([r * np.cos(th), r * np.sin(th), -BODY_H])

def ik(i, target, guess):
    f = lambda q: foot_world(i, q) - target
    lo = [LIMITS['a'][0], LIMITS['b'][0], LIMITS['c'][0]]
    hi = [LIMITS['a'][1], LIMITS['b'][1], LIMITS['c'][1]]
    r = least_squares(f, guess, bounds=(lo, hi), xtol=1e-10, ftol=1e-10)
    return r.x, np.linalg.norm(r.fun)

def foot_offset(phase):
    """phase 0..1. Stance (first DUTY): foot slides back in body frame in a straight line.
    Swing: cycloid forward + smooth lift (zero velocity at lift-off / touch-down)."""
    if phase < DUTY:
        s = phase / DUTY
        return np.array([STRIDE / 2 - STRIDE * s, 0.0, 0.0]), False
    s = (phase - DUTY) / (1 - DUTY)
    x = -STRIDE / 2 + STRIDE * (s - np.sin(2 * np.pi * s) / (2 * np.pi))
    z = LIFT * (1 - np.cos(2 * np.pi * s)) / 2
    return np.array([x, 0.0, z]), True

def solve(n_frames, cycles=2, heading=(1.0, 0.0)):
    hd = np.array([heading[0], heading[1], 0.0]); hd /= np.linalg.norm(hd)
    guesses = [np.array([0.0, 20.0, -20.0])] * 6
    frames = []
    for k in range(n_frames):
        t = k / n_frames * cycles
        rec = {'t': t * CYCLE, 'angles': [], 'swing': []}
        for i in range(6):
            ph = (t + (0.0 if i in TRIPOD else 0.5)) % 1.0
            off, sw = foot_offset(ph)
            tgt = home(i) + hd * off[0] + np.array([0, 0, off[2]])
            q, err = ik(i, tgt, guesses[i])
            assert err < 0.05, (k, i, err, q)
            guesses[i] = q
            rec['angles'].append(q.tolist()); rec['swing'].append(sw)
        rec['body_x'] = float(t * 2 * STRIDE)       # body travel (2 strides per cycle)
        frames.append(rec)
    return frames

if __name__ == '__main__':
    fr = solve(48, cycles=1)
    A = np.array([f['angles'] for f in fr])          # frames x legs x 3
    print('angle ranges (deg) per joint:')
    for j, nme in enumerate('coxa femur knee'.split()):
        print(f'  {nme}: {A[:,:,j].min():.1f} .. {A[:,:,j].max():.1f}')
    dt = CYCLE / 48
    rate = np.abs(np.diff(np.concatenate([A, A[:1]]), axis=0)).max(axis=(0, 1)) / dt
    print('peak joint speed deg/s (coxa, femur, knee):', np.round(rate, 0), ' MG90S ~ 600 deg/s at 4.8 V')
    print('body speed mm/s:', 2 * STRIDE / CYCLE)
    # collision checks
    names = ['Leg_A', 'Leg_B', 'Leg_C_1', 'Leg_C_2']
    worst = 0
    for k in range(0, 48, 3):
        for i in range(6):
            bad = check_leg(i, *fr[k]['angles'][i])
            if bad:
                print('self/body collision', k, i, bad); worst += 1
        for i in range(6):
            j = (i + 1) % 6
            mi = leg_mats(i, *fr[k]['angles'][i]); mj = leg_mats(j, *fr[k]['angles'][j])
            mi = dict(zip(names, list(mi) + [mi[2]])); mj = dict(zip(names, list(mj) + [mj[2]]))
            v = sum(ov(P(x), mi[x], P(y), mj[y]) for x in names for y in names)
            if v > 0.5:
                print('neighbour collision', k, i, j, round(v, 1)); worst += 1
    print('collision events:', worst)
    # standing load: femur torque estimate from geometry at stance midpoint
    json.dump(fr, open('/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work/gait_frames.json', 'w'))
