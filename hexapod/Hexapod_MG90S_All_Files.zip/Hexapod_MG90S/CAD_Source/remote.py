import sys
sys.path.insert(0, '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work')
from cad import *
from manifold3d import FillRule, OpType
import numpy as np

# ------------------------------------------------------------- layout (top view, mm)
H_SPLIT = 16.0          # bottom shell 0..16, top shell 16..H_TOP
H_TOP = 34.0
WALL = 2.2
PLATE = 2.4             # top plate / floor thickness
CHAMF = 3.0
JOY = [(-50.0, 4.0), (50.0, 4.0)]
JOY_HOLES = (26.5 / 2, 20.5 / 2)      # KY-023 mounting holes (x, y half-spacing) - verify
JOY_PCB_TOP = H_TOP - PLATE - 11.0    # PCB top face height so the gimbal sits just under the plate
KNOB = (0.0, 30.0)
SLIDER_X, SLIDER_Y0, SLIDER_Y1 = 0.0, -47.0, 15.0   # 62 mm slot (60 mm travel)
SLIDER_SCREWS = 35.0                                 # +-35 mm from slot centre (bare 60 mm slide pot) - verify
SWITCH = (-24.0, 26.0)                               # KCD11 rocker 19 x 13
BUTTON = (24.0, 26.0)                                # 12 mm momentary
SCREWS = [(-44, 34), (44, 34), (-75, 0), (75, 0), (-40, -50), (40, -50)]
ESP = (-14.6, 14.6, -14.0, 38.0)                     # DevKit V1 30-pin 28.3 x 51.5, USB toward +y
TP = (19.0, 36.8, 12.0, 39.8)                        # TP4056 USB-C module 17.8 x 27.8
BATT = (-70.0, -20.0, -18.0, 18.0)                   # 1S LiPo 103450 (50 x 34 x 10)

def outline():
    parts = [rect(-45, 45, -56, 42)]
    for s in (1, -1):
        parts.append(CrossSection.batch_hull([circ(30, s * 60, 2, 64), circ(22, s * 50, -44, 64),
                                              rect(s * 30 - 15, s * 30 + 15, -56, 42)]))
    o = CrossSection.batch_boolean(parts, OpType.Add)
    return o.offset(-6, JoinType.Round, circular_segments=24).offset(6, JoinType.Round, circular_segments=24)

def hexagon2d(r, x=0, y=0, rot=0):
    a = np.radians(np.arange(6) * 60 + rot)
    return CrossSection([np.stack([x + r * np.cos(a), y + r * np.sin(a)], 1)], FillRule.NonZero)

def text2d(s, size, x, y, mirror=False):
    from matplotlib.textpath import TextPath
    from matplotlib.font_manager import FontProperties
    tp = TextPath((0, 0), s, size=size, prop=FontProperties(family='DejaVu Sans', weight='bold'))
    polys = [np.asarray(p) for p in tp.to_polygons() if len(p) > 2]
    cs = CrossSection(polys, FillRule.EvenOdd)
    b = cs.bounds()
    cs = cs.translate([-(b[0] + b[2]) / 2, -(b[1] + b[3]) / 2])
    if mirror:
        cs = cs.mirror([1, 0])
    return cs.translate([x, y])

def chamfered_slab(cs, z0, z1, ch_top=0.0, ch_bot=0.0):
    """extrusion of cs from z0 to z1 with 45-degree chamfers at top/bottom."""
    pieces = []
    zb, zt = z0 + ch_bot, z1 - ch_top
    pieces.append(cs.extrude(zt - zb).translate([0, 0, zb]))
    if ch_top > 0:
        pieces.append(Manifold.batch_hull([cs.extrude(0.01).translate([0, 0, zt - 0.01]),
                                           cs.offset(-ch_top, JoinType.Round, circular_segments=24).extrude(0.01).translate([0, 0, z1 - 0.01])]))
    if ch_bot > 0:
        pieces.append(Manifold.batch_hull([cs.offset(-ch_bot, JoinType.Round, circular_segments=24).extrude(0.01).translate([0, 0, z0]),
                                           cs.extrude(0.01).translate([0, 0, zb])]))
    return union(pieces)

def tri_pattern(region, s=12.0, rib=2.2):
    from truss import tri_grid
    out = []
    b = region.bounds()
    for t in tri_grid(b, s, 0):
        tc = CrossSection([t], FillRule.NonZero).offset(-rib / 2, JoinType.Miter)
        if tc.is_empty():
            continue
        pc = tc ^ region
        if pc.area() > 0.8 * tc.area():
            out.append(pc)
    return CrossSection.batch_boolean(out, OpType.Add) if out else None

# ------------------------------------------------------------- top shell
def top_shell():
    o = outline()
    inner = o.offset(-WALL, JoinType.Round, circular_segments=24)
    outer = chamfered_slab(o, H_SPLIT, H_TOP, ch_top=CHAMF)
    cav = inner.extrude(H_TOP - PLATE - H_SPLIT + 0.01).translate([0, 0, H_SPLIT - 0.01])
    shell = outer - cav
    # locating lip that drops into the bottom shell
    lip_o = inner.offset(-0.25, JoinType.Round, circular_segments=24)
    lip = (lip_o - lip_o.offset(-1.4, JoinType.Round, circular_segments=24)).extrude(2.5).translate([0, 0, H_SPLIT - 2.5])
    parts = [shell, lip]
    zp = H_TOP - PLATE
    # joystick posts
    for (jx, jy) in JOY:
        for sx in (1, -1):
            for sy in (1, -1):
                parts.append(cyl(3.2, JOY_PCB_TOP, zp + 0.1, jx + sx * JOY_HOLES[0], jy + sy * JOY_HOLES[1], 24))
    # screw bosses (from the split up to the plate)
    for (x, y) in SCREWS:
        parts.append(cyl(3.2, H_SPLIT, zp + 0.1, x, y, 32))
    t = union(parts)
    cuts = []
    for (jx, jy) in JOY:
        cuts.append(cyl(15.0, zp - 1, H_TOP + 1, jx, jy, 96))
        for sx in (1, -1):
            for sy in (1, -1):
                cuts.append(cyl(1.55, JOY_PCB_TOP - 1, JOY_PCB_TOP + 5, jx + sx * JOY_HOLES[0], jy + sy * JOY_HOLES[1], 16))
        # engraved hexagon rings around each stick
        ring = hexagon2d(23.5, jx, jy, 30) - hexagon2d(21.5, jx, jy, 30)
        cuts.append(ring.extrude(1.0).translate([0, 0, H_TOP - 0.8]))
    # speed knob: 7.2 bushing hole + anti-rotation tab hole, engraved hex plate
    cuts.append(cyl(3.6, zp - 1, H_TOP + 1, KNOB[0], KNOB[1], 48))
    cuts.append(cyl(1.6, zp - 1, H_TOP + 1, KNOB[0] + 7.8, KNOB[1], 16))
    cuts.append((hexagon2d(11.5, *KNOB, 30) - hexagon2d(10.3, *KNOB, 30)).extrude(1).translate([0, 0, H_TOP - 0.8]))
    # slider slot + screw holes + engraved scale ticks
    cuts.append(rbox(SLIDER_X - 1.8, SLIDER_X + 1.8, SLIDER_Y0, SLIDER_Y1, zp - 1, H_TOP + 1, 1.7))
    cy_ = (SLIDER_Y0 + SLIDER_Y1) / 2
    for s in (1, -1):
        cuts.append(cyl(1.15, zp - 1, H_TOP + 1, SLIDER_X, cy_ + s * SLIDER_SCREWS, 16))
        cuts.append(cyl(2.1, H_TOP - 1.2, H_TOP + 1, SLIDER_X, cy_ + s * SLIDER_SCREWS, 16))
    for k in range(7):
        y = SLIDER_Y0 + 1 + k * (SLIDER_Y1 - SLIDER_Y0 - 2) / 6
        w = 6.0 if k in (0, 3, 6) else 3.5
        for s in (1, -1):
            cuts.append(box(s * 4.5 - (w if s < 0 else 0), s * 4.5 + (w if s > 0 else 0), y - 0.45, y + 0.45, H_TOP - 0.7, H_TOP + 1))
    # "HEIGHT" label rotated along the slider, "SPEED" under the knob
    lab = text2d('HEIGHT', 4.2, 0, 0).rotate(90).translate([-13.0, cy_])
    cuts.append(lab.extrude(1.0).translate([0, 0, H_TOP - 0.7]))
    # power rocker (19 x 13) and action button (12 mm)
    cuts.append(box(SWITCH[0] - 6.6, SWITCH[0] + 6.6, SWITCH[1] - 9.6, SWITCH[1] + 9.6, zp - 1, H_TOP + 1))
    cuts.append(cyl(6.1, zp - 1, H_TOP + 1, BUTTON[0], BUTTON[1], 48))
    # engraved truss triangles on both grips (decorative, 0.7 deep)
    for s in (1, -1):
        g = (CrossSection.batch_hull([circ(16, s * 52, -40, 48), circ(12, s * 42, -52, 48)]))
        g = g ^ o.offset(-CHAMF - 2.5, JoinType.Round, circular_segments=24)
        tp = tri_pattern(g, 9.0, 1.8)
        if tp is not None:
            cuts.append(tp.extrude(1.0).translate([0, 0, H_TOP - 0.7]))
    # pilot holes in screw bosses
    for (x, y) in SCREWS:
        cuts.append(cyl(1.55, H_SPLIT - 1, H_SPLIT + 5, x, y, 24))
    # back wall cut-outs that fall in the top shell half (ESP32 micro-USB upper half)
    cuts.append(rbox(-6.0, 6.0, 30, 60, 9.5, 17.5, 1.5))
    return diff(t, cuts)

# ------------------------------------------------------------- bottom shell
def bottom_shell():
    o = outline()
    inner = o.offset(-WALL, JoinType.Round, circular_segments=24)
    outer = chamfered_slab(o, 0, H_SPLIT, ch_bot=2.0)
    cav = inner.extrude(H_SPLIT - PLATE + 1).translate([0, 0, PLATE])
    shell = outer - cav
    parts = [shell]
    # screw bosses
    for (x, y) in SCREWS:
        parts.append(cyl(3.2, PLATE - 0.1, H_SPLIT - 2.6, x, y, 32))
    # ESP32 rails: board sits on ledges at z=11 between two rails (board edge slots)
    x0, x1, y0, y1 = ESP
    # side locating rails and end ledges (header pins run along the long edges, so the board rests on its ends)
    for xs in (x0 - 2.4, x1 + 0.4):
        parts.append(box(xs, xs + 2.0, y0 + 4, y1 - 4, PLATE - 0.1, 13.5))
    for ys in (y0 + 0.3, y1 - 2.3):
        parts.append(box(x0 + 3.5, x1 - 3.5, ys, ys + 2.0, PLATE - 0.1, 11.0))
    parts.append(box(x0 + 3.5, x1 - 3.5, y0 - 2.2, y0 - 0.2, PLATE - 0.1, 13.5))
    # TP4056 pocket walls
    tx0, tx1, ty0, ty1 = TP
    parts.append(box(tx0 - 1.6, tx1 + 1.6, ty0 - 1.6, ty0, PLATE - 0.1, PLATE + 3))
    for xs in (tx0 - 1.6, tx1):
        parts.append(box(xs, xs + 1.6, ty0 - 1.6, ty1, PLATE - 0.1, PLATE + 3))
    # battery bay fence + strap posts
    bx0, bx1, by0, by1 = BATT
    fence = rbox(bx0 - 1.6, bx1 + 1.6, by0 - 1.6, by1 + 1.6, PLATE - 0.1, PLATE + 3, 1.5) - \
        box(bx0, bx1, by0, by1, PLATE - 1, PLATE + 5) - box(bx1 - 1, bx1 + 5, -5, 5, 0, 20)
    parts.append(fence)
    b = union(parts)
    cuts = []
    # rail slots for the ESP32 board edges (1.6 board + clearance at z 11)
    for (x, y) in SCREWS:
        cuts.append(cyl(1.2, -1, H_SPLIT, x, y, 16))
        cuts.append(cyl(2.2, -1, 2.0, x, y, 24))   # head counterbore
    # ESP32 micro-USB (lower half) and TP4056 USB-C in the back wall
    cuts.append(rbox(-6.0, 6.0, 30, 60, 9.5, 17.5, 1.5))
    cuts.append(rbox((tx0 + tx1) / 2 - 5.2, (tx0 + tx1) / 2 + 5.2, 30, 60, PLATE + 1.6, PLATE + 6.2, 1.4))
    # TP4056 status LED window (top-side LEDs visible through a slot in the floor? -> light pipe slot)
    cuts.append(box(tx0 + 3, tx1 - 3, ty0 + 4, ty0 + 6, -1, PLATE + 0.5))
    # battery strap slots
    for x in (bx0 + 10, bx1 - 10):
        cuts.append(box(x - 1.5, x + 1.5, by0 - 4.5, by0 - 2.2, -1, PLATE + 1))
        cuts.append(box(x - 1.5, x + 1.5, by1 + 2.2, by1 + 4.5, -1, PLATE + 1))
    # engraved underside: mirrored name + hex emblem + truss triangles on grips
    cuts.append(text2d('HEXAPOD', 9.0, 0, -18).extrude(1.0).translate([0, 0, -0.3]))
    cuts.append(text2d('MG90S  ESP-NOW', 4.0, 0, -31).extrude(1.0).translate([0, 0, -0.3]))
    cuts.append((hexagon2d(11, 0, 4, 30) - hexagon2d(9, 0, 4, 30) + hexagon2d(5, 0, 4, 30)).extrude(1.0).translate([0, 0, -0.3]))
    for s in (1, -1):
        g = CrossSection.batch_hull([circ(17, s * 55, -6, 48), circ(13, s * 46, -44, 48)]) ^ o.offset(-5, JoinType.Round, circular_segments=24)
        tp = tri_pattern(g, 10.0, 2.0)
        if tp is not None:
            cuts.append(tp.extrude(1.0).translate([0, 0, -0.3]))
    return diff(b, cuts)

if __name__ == '__main__':
    import trimesh, os
    out = '/tmp/claude-0/-home-claude/d1b0923b-3f50-5026-9106-67d417f038ab/scratchpad/work/stl/'
    for n, f in (('Remote_Top', top_shell), ('Remote_Bottom', bottom_shell)):
        m = f()
        mm = m.to_mesh()
        trimesh.Trimesh(mm.vert_properties[:, :3], mm.tri_verts).export(out + n + '.stl')
        print(n, m.status(), round(m.volume() / 1000, 1), np.round(m.bounding_box(), 1))
