# MG90S Hexapod - all files (latest, 21 Oct 2026)

## Print_Files  (Bambu Lab A1 ready, no supports, PLA/PETG 0.2 mm, 3 walls, 15% gyroid)
- Plates/      5 full build plates: import one and slice
- Parts/       single parts, quantity in file name
- Remote/      09_Remote_Top_x1 (already face down), 10_Remote_Bottom_x1
- Hexapod_MG90S_BambuProject_robot_only.3mf   Bambu project with the 5 robot plates (no remote case)
Print one Parts/03_Leg_A_coxa_bracket_x6.stl first and test-fit an MG90S.

## Previews
- hexapod_truss_preview.png   assembled robot
- print_plates.png            the 5 plates
- hexapod_walk.mp4            tripod walk cycle (real speed, slow motion, top view)
- remote_case_preview.png     remote case

## CAD_Source  (Python, regenerate everything)
Needs: pip install manifold3d trimesh numpy scipy matplotlib imageio-ffmpeg playwright ; npm install three@0.160.0 (in viewer/)
- cad.py          shared helpers + MG90S servo pocket, horn, pivot, bearing features
- parts.py        robot parts (body, lid, Leg_A/B/C_1/C_2, shaft, washer) + geometry constants
- truss.py        triangle truss cut-outs (the *_t() functions are the latest parts)
- assembly.py     leg kinematics + collision checks
- gait.py         inverse kinematics + tripod gait, joint/collision validation
- pack3mf.py      exports Bambu 3MF + A1 STLs (python3 pack3mf.py <out.3mf>)
- remote.py       remote case;  remote_check.py  component fit checks
- render_walk.py, shot.py, viewer/  three.js renders + walk video
- load.py         reads the original MG996R 3MF (reference only)
Note: scripts contain absolute paths from the original session; edit the BASE / path lines at the top before running.

## Key numbers
Coxa radius 70 mm, coxa->femur 24.85 mm, femur 52 mm, knee->foot tip 90 mm.
Joint ranges: coxa +-35, femur -35..+75, knee -55..+90 deg.
Walk: 0.8 s cycle, 40 mm stride, 22 mm lift, ~10 cm/s. Body height slider 65-95 mm.

## Update 23 Oct 2026 - M2 brass heat-set inserts
3.1 mm x 5 mm deep holes (fits M2 inserts 3-4 mm long) at:
- Body: 4 lid posts (top) + 8 PCA9685 posts
- Claw feet: 2 per foot (top face); foot screws moved to +-3.6 mm
- Remote top shell: 6 case screw bosses + 8 joystick posts
Everything else (servo tabs, pivot discs, horns) still uses plain screws - no room for inserts there.
Fit inserts with a soldering iron at ~220 C (PLA), press straight until flush.

## Update 23 Oct 2026 - cable exits through the END of each servo pocket
The side notches are gone. Every servo pocket now has a centred 4.2 mm slot straight through
both end walls, from the pocket floor up to just under the tab screw hole (MG90S lead leaves the end face).
Fitting: stand the plug on its edge, push it out through the slot, then lower the servo in.
Tab screws are now M2.5x6 (pilot 6.5 mm deep).
