UNDER-DESK PARTS DRAWER  -  The Almanac, entry XIII (V1, 14 Nov 2026)
=========================================================================

WHAT'S IN THIS ZIP
  stl\      print-ready files, already rotated the right way for the bed
  step\     the same parts for Fusion / FreeCAD, plus assembly_one_module.step
  drawer.py the CAD script. Change the numbers at the top and run it to remake everything:
              pip install cadquery
              python drawer.py

WHAT TO PRINT FOR TWO DRAWERS
  File                     Qty  Material  Notes
  test_rail_slice.stl       1   PETG      print these two FIRST (about 30 min)
  test_drawer_slice.stl     1   PLA
  rail_left.stl             2   PETG      4 walls, 25% gyroid, no supports
  rail_right.stl            2   PETG      4 walls, 25% gyroid, no supports
  drawer.stl                2   PLA/PETG  3 walls, 15% infill, no supports (227 x 191 mm, fits the A1 and the P2S)
  bin_*.stl                 any PLA       2 walls, 15% infill, no supports
  All at 0.2 mm layers. Print every file exactly as it loads in Bambu Studio - don't rotate anything.

ALSO NEED
  - 25 mm wide 3M VHB (or similar heavy-duty double-sided foam tape), about 80 cm
  - 4 x M3 x 6 mm screws (the drawer stops)
  - isopropyl alcohol + a paper towel

STEP 1 - FIT TEST
  Slide test_drawer_slice into test_rail_slice from the end with the angled entry.
  It should slide freely with only a tiny wiggle.
    Too tight -> in drawer.py change  GAP = 0.5  to  GAP = 0.6  and run it again.
    Too loose -> change it to 0.4.
  Screw an M3 x 6 up into the small hole under the rail slice to check it bites.

STEP 2 - PUT EACH MODULE TOGETHER ON THE TABLE
  1. Lay a rail_left and a rail_right on the table, flat flanges down.
  2. Slide a drawer into both rails from the front (the end with the angled entry) all the way in.
     The drawer now holds the rails at exactly the right spacing - that's your alignment jig.
  3. Do NOT fit the stop screws yet.

STEP 3 - STICK IT UP
  1. Wipe the underside of the desk and the top of each rail flange with isopropyl alcohol. Let it dry.
  2. Stick tape along the full length of each flange (the wide flat strip on top of each rail).
  3. Peel the backing. Hold the whole module (rails + drawer) up under the desk:
       - front ends of the rails pushed hard against the back of the black front frame rail
       - left module about 1 mm from the left side
  4. Press hard along every bit of both flanges for 30 seconds.
  5. Do the right module the same way, leaving about a 2 mm gap to the left module.

STEP 4 - STOP SCREWS
  Push the drawer all the way in. Under the front of each rail (just behind the black frame rail)
  there's a small hole in the bottom lip. Screw an M3 x 6 straight up into each one until the head
  touches. Its tip now rides in a groove under the drawer runner and stops the drawer at 151 mm out.

STEP 5 - WAIT
  Leave it 24 hours before loading - the tape reaches full strength after that.
  Keep each drawer under about 1 kg. Components are fine; tools and power bricks are not.
  If a rail ever starts to peel, there are 3 countersunk holes in each flange for small wood screws
  (3.5 x 12 mm) as a backup.

USING IT
  - Pull-out is 151 mm. The front 3 rows of bins come fully clear of the desk edge; the back row
    only partly does, so keep spare stock back there.
  - To take a drawer right out: unscrew its two stop screws from underneath, then pull.
  - Bins are standard Gridfinity (42 mm grid). Any Gridfinity bin up to 7 units (49 mm) tall fits,
    without a stacking lip. MakerWorld's Gridfinity bin generator makes any size you want.

KEY NUMBERS (change at the top of drawer.py)
  SPACE_WIDTH 400   SPACE_HEIGHT 80   FRAME_DROP 20   FRAME_THICK 20 (guess - measure it!)
  CARRIER_LEN 195   GAP 0.5   ENGAGE_AT_STOP 38
