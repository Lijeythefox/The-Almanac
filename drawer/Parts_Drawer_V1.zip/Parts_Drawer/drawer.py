"""
UNDER-DESK COMPONENT DRAWER  -  parametric CAD script (CadQuery)
Elijah's Almanac, entry XIII

How to run (Windows):
    pip install cadquery
    python drawer.py
Outputs go to  stl/  (print-ready, already rotated for the bed) and  step/  (for Fusion / FreeCAD).

Coordinate system used while designing (all mm):
    X = left to right across the desk
    Y = front to back  (Y = 0 is the BACK face of the front frame rail)
    Z = up/down        (Z = 0 is the underside of the desk, everything hangs below it, so Z is negative)
"""

import os
import cadquery as cq

# ---------------------------------------------------------------- measurements
SPACE_WIDTH    = 400.0   # clear width under the desk
SPACE_HEIGHT   = 80.0    # desk underside down to the lowest point allowed
FRAME_DROP     = 20.0    # how far the front frame rail hangs below the desk underside
FRAME_THICK    = 20.0    # front-to-back thickness of that rail (drawer front sits flush with its front face)
CARRIER_LEN    = 195.0   # rail length behind the frame rail (space depth is 200, 5 mm spare)
MODULES        = 2       # drawers side by side
MODULE_GAP     = 2.0     # gap between the two modules

# ---------------------------------------------------------------- rail (carrier) design
WALL_T     = 3.0    # rail side wall thickness
FLANGE_W   = 30.0   # width of the taped top flange
FLANGE_T   = 4.0    # thickness of the taped top flange
GUSSET     = 12.0   # triangle brace between flange and wall
RIB_W      = 8.0    # how far the lower lip and upper rib stick in from the wall
LIP_T      = 3.5    # lower lip thickness (drawer runner rides on this)
RIB_T      = 3.0    # upper rib thickness (stops the drawer tipping)
RUNNER_T   = 5.0    # drawer runner thickness
GAP        = 0.5    # sliding clearance everywhere
CARRIER_BOTTOM = -(SPACE_HEIGHT - 2.0)  # 2 mm spare above your legs

# ---------------------------------------------------------------- drawer design
DRAWER_TOP     = -(FRAME_DROP + 2.0)    # 2 mm under the frame rail
SIDE_T         = 2.4
FRONT_T        = 3.0
BACK_T         = 2.4
FLOOR_T        = 2.0
ENGAGE_AT_STOP = 38.0   # how much runner is still inside the rail when fully pulled out
REAR_STOP_LEN  = 6.0
SCREW_Y        = 8.0    # stop screw position, measured back from the front end of the rail
SCREW_HOLE     = 2.6    # pilot hole for an M3 x 6 screw to self-tap into
GROOVE_W       = 3.6    # groove under the runner that the screw tip rides in
GROOVE_D       = 2.6

# ---------------------------------------------------------------- Gridfinity
GF = 42.0
GF_COLS, GF_ROWS = 4, 4
UNDER_POCKET = 1.2      # plastic under each baseplate pocket

# ---------------------------------------------------------------- derived numbers
MODULE_W   = (SPACE_WIDTH - (MODULES - 1) * MODULE_GAP - 2.0) / MODULES   # 1 mm margin each end
LIP_TOP    = CARRIER_BOTTOM + LIP_T
RUNNER_TOP = LIP_TOP + RUNNER_T
RIB_BOT    = RUNNER_TOP + GAP
RIB_TOP    = RIB_BOT + RIB_T
RIB_IN     = WALL_T + RIB_W                 # inner edge of lip/rib (x, left rail)
DRAWER_X0  = RIB_IN + GAP                   # drawer side wall outer face (left)
RUNNER_X0  = WALL_T + GAP                   # runner tip (left)
DRAWER_BOT = LIP_TOP                        # drawer floor sits flush with runner bottom
DRAWER_Y0  = -FRAME_THICK                   # drawer front face (closed)
DRAWER_Y1  = CARRIER_LEN - REAR_STOP_LEN    # drawer back face (closed)
TRAVEL     = DRAWER_Y1 - ENGAGE_AT_STOP
GROOVE_END = SCREW_Y + 1.5 + TRAVEL         # groove's closed end (drawer closed) -> hits the screw at full pull-out
SCREW_X    = WALL_T + RIB_W / 2             # centre of the lower lip
STOP_Z0, STOP_Z1 = -40.0, -28.0             # height band of the rear stop block

HERE = os.path.dirname(os.path.abspath(__file__))


def box(x0, x1, y0, y1, z0, z1):
    return cq.Workplane("XY").box(x1 - x0, y1 - y0, z1 - z0, centered=False).translate((x0, y0, z0))


def rrect_wire(size_x, size_y, r, z):
    sk = cq.Sketch().rect(size_x, size_y).vertices().fillet(r)
    face = sk._faces.Faces()[0]
    return face.outerWire().moved(cq.Location(cq.Vector(0, 0, z)))


def loft_stack(levels):
    """levels = [(size_x, size_y, radius, z), ...] bottom to top -> ruled loft solid"""
    solids = []
    for a, b in zip(levels[:-1], levels[1:]):
        solids.append(cq.Solid.makeLoft([rrect_wire(*a), rrect_wire(*b)], True))
    out = cq.Workplane("XY").add(solids[0])
    for s in solids[1:]:
        out = out.union(cq.Workplane("XY").add(s))
    return out


# ================================================================= RAIL (left hand, installed position)
def make_rail_left():
    L = CARRIER_LEN
    r = box(0, WALL_T, 0, L, CARRIER_BOTTOM, 0)                          # side wall
    r = r.union(box(0, FLANGE_W, 0, L, -FLANGE_T, 0))                    # taped flange
    g = (cq.Workplane("XZ").polyline([(WALL_T - 0.1, -FLANGE_T + 0.1),
                                       (WALL_T - 0.1, -FLANGE_T - GUSSET),
                                       (WALL_T + GUSSET, -FLANGE_T + 0.1)]).close()
         .extrude(-L))                                                     # gusset brace
    r = r.union(g)
    r = r.union(box(WALL_T - 0.1, RIB_IN, 0, L, CARRIER_BOTTOM, LIP_TOP))  # lower lip
    r = r.union(box(WALL_T - 0.1, RIB_IN, 0, L, RIB_BOT, RIB_TOP))        # upper rib
    # stop blocks
    r = r.union(box(WALL_T - 0.1, DRAWER_X0 + 3.0, L - REAR_STOP_LEN, L, STOP_Z0, STOP_Z1))
    # lead-in chamfers at the channel mouth so the runner finds its way in
    lead = (cq.Workplane("YZ").polyline([(-0.1, LIP_TOP - 1.5), (2.0, LIP_TOP), (2.0, RIB_BOT),
                                          (-0.1, RIB_BOT + 1.5)]).close()
            .extrude(RIB_IN + 1).translate((WALL_T - 0.05, 0, 0)))
    r = r.cut(lead)
    # stop screw: M3 x 6 screwed up from underneath, its tip rides in the runner groove
    r = r.cut(cq.Workplane("XY").workplane(offset=CARRIER_BOTTOM - 1).center(SCREW_X, SCREW_Y)
              .circle(SCREW_HOLE / 2).extrude(LIP_T + 2))
    # optional screw holes (backup if the tape ever lets go) - countersunk from below
    for y in (25.0, L / 2, L - 25.0):
        hole = cq.Workplane("XY").workplane(offset=-FLANGE_T - 1).center(20.0, y).circle(2.1).extrude(FLANGE_T + 2)
        csk = cq.Workplane("XY").add(cq.Solid.makeCone(4.3, 0.0, 4.3, cq.Vector(20.0, y, -FLANGE_T - 0.01)))
        r = r.cut(hole).cut(csk)
    return r


def make_rail_right():
    return make_rail_left().mirror("YZ").translate((MODULE_W, 0, 0))


# ================================================================= DRAWER (installed, closed position)
def gridfinity_pocket():
    top = 0.0
    return loft_stack([
        (36.3, 36.3, 1.15, top - 4.65),
        (37.7, 37.7, 1.85, top - 3.95),
        (37.7, 37.7, 1.85, top - 2.15),
        (42.0, 42.0, 4.0, top),
        (42.0, 42.0, 4.0, top + 1.0),
    ])


def runner_grooves(d):
    for xc in (SCREW_X, MODULE_W - SCREW_X):
        d = d.cut(box(xc - GROOVE_W / 2, xc + GROOVE_W / 2, DRAWER_Y0 - 1, GROOVE_END, DRAWER_BOT - 1, DRAWER_BOT + GROOVE_D))
    return d


def make_drawer():
    x0, x1 = DRAWER_X0, MODULE_W - DRAWER_X0
    y0, y1 = DRAWER_Y0, DRAWER_Y1
    zb, zt = DRAWER_BOT, DRAWER_TOP
    d = box(x0, x1, y0, y1, zb, zt)
    d = d.cut(box(x0 + SIDE_T, x1 - SIDE_T, y0 + FRONT_T, y1 - BACK_T, zb + FLOOR_T, zt + 1))
    # runners
    d = d.union(box(RUNNER_X0, x0 + 0.1, y0, y1, zb, RUNNER_TOP))
    d = d.union(box(x1 - 0.1, MODULE_W - RUNNER_X0, y0, y1, zb, RUNNER_TOP))
    # chamfer the back end of the runners (lead-in)
    for xa, xb in ((RUNNER_X0 - 0.1, x0), (x1, MODULE_W - RUNNER_X0 + 0.1)):
        wedge = (cq.Workplane("YZ").polyline([(y1 - 3.0, RUNNER_TOP + 0.1), (y1 + 0.1, RUNNER_TOP + 0.1),
                                               (y1 + 0.1, RUNNER_TOP - 2.0)]).close()
                 .extrude(xb - xa).translate((xa, 0, 0)))
        d = d.cut(wedge)
    # Gridfinity baseplate block + pockets
    gx0 = MODULE_W / 2 - GF * GF_COLS / 2
    gy0 = y0 + FRONT_T + 0.5
    gtop = zb + UNDER_POCKET + 4.65
    d = d.union(box(x0 + 1, x1 - 1, y0 + 1, gy0 + GF * GF_ROWS + 1.0, zb + 0.5, gtop))
    pocket = gridfinity_pocket()
    pockets = None
    for i in range(GF_COLS):
        for j in range(GF_ROWS):
            p = pocket.translate((gx0 + GF * (i + 0.5), gy0 + GF * (j + 0.5), gtop))
            pockets = p if pockets is None else pockets.union(p)
    d = d.cut(pockets)
    # J-hook pull handle on the front
    hw = 90.0
    hx0 = MODULE_W / 2 - hw / 2
    d = d.union(box(hx0, hx0 + hw, y0 - 15.0, y0 + 0.1, zb, zb + 3.0))
    d = d.union(box(hx0, hx0 + hw, y0 - 15.0, y0 - 12.0, zb, zb + 12.0))
    d = d.edges("|Z").edges(cq.selectors.BoxSelector((hx0 - 1, y0 - 16, zb - 1), (hx0 + hw + 1, y0 - 11, zb + 13))).fillet(1.4)
    # grooves under the runners for the stop screws
    d = runner_grooves(d)
    return d


# ================================================================= BINS
def make_bin(nx, ny, units, wall=1.2):
    foot = loft_stack([
        (35.6, 35.6, 0.8, 0.0),
        (37.2, 37.2, 1.6, 0.8),
        (37.2, 37.2, 1.6, 2.6),
        (41.5, 41.5, 3.75, 4.75),
    ])
    b = None
    for i in range(nx):
        for j in range(ny):
            f = foot.translate((GF * (i + 0.5), GF * (j + 0.5), 0))
            b = f if b is None else b.union(f)
    W, D = GF * nx - 0.5, GF * ny - 0.5
    cx, cy = GF * nx / 2, GF * ny / 2
    H = 7.0 * units
    body = (cq.Workplane("XY").workplane(offset=4.75).sketch().rect(W, D).vertices().fillet(3.75)
            .finalize().extrude(H - 4.75).translate((cx, cy, 0)))
    b = b.union(body)
    inner = (cq.Workplane("XY").workplane(offset=5.75).sketch().rect(W - 2 * wall, D - 2 * wall)
             .vertices().fillet(3.75 - wall).finalize().extrude(H).translate((cx, cy, 0)))
    b = b.cut(inner)
    # finger scoop along the front inside edge so small parts slide out
    scoop = (cq.Workplane("YZ").polyline([(-0.1, 5.75 - 0.01), (8.0, 5.75 - 0.01), (-0.1, 13.75)]).close()
             .extrude(W - 2 * wall - 1.0).translate((GF * nx / 2 - (W - 2 * wall - 1.0) / 2, 0.25 + wall, 0)))
    b = b.union(scoop.intersect(inner.translate((0, 0, 0))))
    return b


# ================================================================= EXPORT
def to_print(wp, kind):
    if kind == "rail":
        wp = wp.rotate((0, 0, 0), (0, 1, 0), -90)
    bb = wp.val().BoundingBox()
    return wp.translate((-bb.xmin, -bb.ymin, -bb.zmin))


def export(wp, name, step=True):
    os.makedirs(os.path.join(HERE, "stl"), exist_ok=True)
    os.makedirs(os.path.join(HERE, "step"), exist_ok=True)
    cq.exporters.export(wp, os.path.join(HERE, "stl", name + ".stl"), tolerance=0.03, angularTolerance=0.15)
    if step:
        cq.exporters.export(wp, os.path.join(HERE, "step", name + ".step"))
    bb = wp.val().BoundingBox()
    print(f"{name:28s} {bb.xlen:7.1f} x {bb.ylen:7.1f} x {bb.zlen:6.1f} mm")


if __name__ == "__main__":
    print(f"module width {MODULE_W:.1f}  drawer travel {TRAVEL:.1f}  engagement at stop {ENGAGE_AT_STOP}")
    rail_l = make_rail_left()
    drawer = make_drawer()
    rail_print = to_print(rail_l, "rail")
    export(rail_print, "rail_left")
    export(rail_print.mirror("YZ"), "rail_right")
    export(to_print(drawer, "drawer"), "drawer")
    for nx, ny, u in ((1, 1, 3), (2, 1, 3), (2, 2, 3), (1, 2, 6)):
        export(make_bin(nx, ny, u), f"bin_{nx}x{ny}_{u}u")
    # fit test: 30 mm slice of rail + matching slice of drawer edge
    t_rail = rail_l.intersect(box(-1, FLANGE_W + 1, 0, 30, CARRIER_BOTTOM - 1, 1))
    t_draw = drawer.intersect(box(RUNNER_X0 - 1, DRAWER_X0 + 22, 40, 70, DRAWER_BOT - 1, DRAWER_TOP + 1))
    export(to_print(t_rail, "rail"), "test_rail_slice", step=False)
    export(to_print(t_draw, "drawer"), "test_drawer_slice", step=False)
    # full assembly for previews
    asm = (cq.Assembly()
           .add(rail_l, name="rail_l").add(make_rail_right(), name="rail_r").add(drawer, name="drawer"))
    asm.save(os.path.join(HERE, "step", "assembly_one_module.step"))
