# P-01 Pocket Player: PCBs, rev 0.3

These are the two circuit boards that match the rev 0.3 3D model, which has the motor-spun wheel.

| Board | Size | Layers | Thickness | Parts |
|---|---|---|---|---|
| `P01_Main` | 51 × 37 mm | 4 | 1.0 mm | ESP32-WROVER-E, microSD, PCM5102A audio DAC, 3.5 mm jack, USB-C charging, power slide switch, volume buttons |
| `P01_Controls` | 51 × 68.5 mm with a 9 mm motor slot | 2 | 1.0 mm | 4 buttons, wheel-press switch, 2 LEDs, AS5600 wheel sensor, TCA9534 button chip, motor driver |

The two boards connect through an 8-pin, 0.5 mm-pitch flat flex cable (J4 on the main board to J1 on the controls board).

## Changes since rev 0.2

- **Power switch fixed.** The slider now points out of the board edge. It was facing inwards.
- **Motor slot.** The controls board has a slot cut up from its bottom edge. The gear motor's rubber roller comes up through it and spins the wheel.
- **Motor driver.** An AO3400A MOSFET with a B5819WS flyback diode sits on the back of the controls board. Solder the motor to the M+ and M- pads beside it.
- **Wheel-press select.** The select switch (SW5) moves 7 mm above the wheel centre, so the whole wheel acts as the select button. The AS5600 stays at the centre, under the 6 × 2.5 mm magnet.
- **Flat flex cable.** Pin 6 now carries the motor PWM signal (ESP32 GPIO2). Pin 7 now carries VSYS, the battery/USB supply, to power the motor.
- **Mounting holes.** The two top holes on the controls board were removed because the battery now sits under them. Two M2 holes remain at the bottom corners. Hold the top edge with a printed ledge.

## Files in each board folder

- `.kicad_pro`, `.kicad_pcb`, `.kicad_sch`: the KiCad project, schematic and board.
- `lib/`, `fp-lib-table`, `sym-lib-table`: the custom footprints and symbols, which KiCad finds automatically.
- `*_gerbers.zip`: upload this to JLCPCB or PCBWay.
- `*_schematic.pdf`: the circuit.
- `*_assembly.pdf`: the label for every part, top and bottom. Many labels are hidden on the board itself, so use this PDF when soldering.
- `preview_*.png`: pictures of both sides of the board.

## Opening the projects

1. Unzip the package.
2. Double-click `P01_Main/P01_Main.kicad_pro`.
3. When KiCad says the files come from an older version, click **Yes** to upgrade them.
4. Repeat steps 2 and 3 for `P01_Controls/P01_Controls.kicad_pro`.

## Ordering (JLCPCB)

**Main board**
1. Upload `P01_Main_gerbers.zip`.
2. Set Layers to **4** and PCB thickness to **1.0 mm**.
3. Leave the stackup on the default.
4. Choose **ENIG** surface finish.

**Controls board**
1. Upload `P01_Controls_gerbers.zip`.
2. Set Layers to **2** and PCB thickness to **1.0 mm**.
3. The motor slot is part of the board outline, so the factory cuts it automatically.

## Having JLCPCB solder the parts (PCBA)

Each board folder has a BOM file (`P01_*_BOM_JLCPCB.csv`) and a placement file (`P01_*_CPL_JLCPCB.csv`). Every LCSC part number in them was checked against LCSC/JLCPCB listings.

**Main board**
1. In the PCB order, turn on **PCB Assembly** and choose **Top side**.
2. Upload `P01_Main_BOM_JLCPCB.csv` and `P01_Main_CPL_JLCPCB.csv`.
3. All 50 parts are on the top side.
4. Not assembled are the battery pads, PROG pads and LCD pads, which only need wires soldered to them.
5. If the ESP32 module (C701348) is out of stock, C2973667 is the same ESP32-WROVER-E-N8R8.

**Controls board**
1. Turn on PCB Assembly and choose **Both sides**.
2. Upload `P01_Controls_BOM_JLCPCB.csv` and `P01_Controls_CPL_JLCPCB.csv`.
3. Bottom side: AS5600, TCA9534, flex connector, motor driver and resistors/capacitors.
4. Top side: the five buttons (SW1–SW5), the two LEDs (D1, D2) and their resistors (R1, R2).
5. The buttons are Alps **SKRKAEE020** (C115357). It's the same size and footprint as the SKRKAEE010 the design was drawn with, with a 1.6 N press. If it's out of stock, any 3.9 × 2.9 mm, 2-pad SKRK switch fits (for example SKRKAHE020, C202388, which is lighter to press).
6. If you'd rather save the cost of top-side assembly, choose **Bottom side** only and solder SW1–SW5, D1, D2, R1 and R2 yourself.

**Before you confirm the order**
- Check JLCPCB's placement preview for every chip. The pin-1 dot must line up with the silkscreen mark, and the USB-C, jack and flex connectors must face the board edge. Rotate any part that's off in their tool before confirming. Their footprints sometimes use a different default rotation from KiCad's.
- Don't open and re-save the CSV files in Excel. Excel adds a hidden character that breaks the upload.

## What was checked

- Both boards are fully routed.
- KiCad's design rule check finds no unconnected pads and no copper clearance errors.
- Each schematic matches its board net-for-net: 0 mismatches, with every footprint linked to a symbol.

The main board still shows two kinds of warning, and both can be left alone:
- **Volume switch holes:** the Alps SKRT switches' own peg holes sit close to their pads. That is the maker's land pattern.
- **Silkscreen at the edges:** some silkscreen runs past the edge where parts overhang it (antenna, jack, slide switch, flat cable connector). The factory trims it.

## Firmware notes

**Programming.** USB-C only charges, so flash the first time through the J6 pads with a 3.3 V USB-serial adapter:
1. Connect the pads: 1 3V3, 2 TX, 3 RX, 4 EN, 5 IO0, 6 GND. The adapter's RX goes to pad 2 and its TX goes to pad 3.
2. Hold IO0 to GND.
3. Tap EN to GND.
4. Upload.

After the first flash, update over Wi-Fi (OTA).

**Motor.** Drive GPIO2 with PWM, at about 20 kHz so it's silent. A 100k resistor holds GPIO2 low at boot, so the motor is off and flashing still works. VSYS is about 3.7–4.2 V on battery and about 4.7 V on USB. Keep the duty cycle at or below about 70% so a 3 V motor isn't overdriven.

**Scrubbing.** Compare the AS5600 angle with the speed you expect from the motor. A sudden slowdown or reversal means a finger is on the wheel.

**Battery life.** With the wheel spinning, expect roughly 6 h on the 1000 mAh cell. With spinning switched off, expect about 8 h. Both are estimates.

| GPIO | Use | GPIO | Use |
|---|---|---|---|
| 14 | LCD SCK | 18 | SD SCK |
| 13 | LCD MOSI | 19 | SD MISO (10k pull-up) |
| 15 | LCD CS | 23 | SD MOSI |
| 27 | LCD DC | 5 | SD CS (10k pull-up) |
| 32 | LCD backlight (PWM) | 26 | I2S BCK |
| EN | LCD RST (shared reset) | 25 | I2S LRCK |
| 33 | I2C SDA | 22 | I2S DIN |
| 4 | I2C SCL | 12 | DAC soft-mute (high = play) |
| 34 | Button chip interrupt (low = event) | 36 | Volume + (low = pressed) |
| 35 | Battery voltage ÷ 2 | 39 | Volume − (low = pressed) |
| 21 | USB present (5 V ÷ 2) | 2 | Wheel motor PWM |

**I2C devices**
- AS5600 at address 0x36
- TCA9534 at address 0x20

**TCA9534 pins**

| Pin | Use |
|---|---|
| P0 | Menu |
| P1 | Prev |
| P2 | Play |
| P3 | Next |
| P4 | Wheel press (select) |
| P5 | Wi-Fi LED (low = on) |
| P6 | Bluetooth LED (low = on) |

## Check before ordering

- **Screen pinout:** compare your screen's pinout with the J5 pads: 1 3V3, 2 GND, 3 MOSI, 4 SCK, 5 CS, 6 DC, 7 RST, 8 BL.
- **Gear motor:** measure yours. The design assumes 6 mm diameter and about 20 mm long including the gearbox.
- **Battery:** it must be 4.5 mm thick or less, and about 58 × 39 mm or smaller.
- **Flat flex cable:** it needs contacts on the same side at both ends.
